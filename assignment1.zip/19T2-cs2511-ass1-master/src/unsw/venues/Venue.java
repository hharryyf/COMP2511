package unsw.venues;

import java.time.LocalDate;
import java.util.*;

import org.json.JSONArray;

import org.json.JSONObject;
// import org.json.JSONTokener;

public class Venue {
	private String name;
	private ArrayList<Room> roomlist;
	private ArrayList<SmallRoom> smallroom;
	private ArrayList<MediumRoom> mediumroom;
	private ArrayList<BigRoom> bigroom;
	private HashMap<String, Request> requestlist;
	public Venue(String name) {
		this.name = name;
		roomlist = new ArrayList<Room>();
		smallroom = new ArrayList<SmallRoom>();
		mediumroom = new ArrayList<MediumRoom>();
		bigroom = new ArrayList<BigRoom>();
		requestlist = new HashMap<String, Request>();
	}
	public String getName() {
		return name;
	}
	/*
	public void setName(String name) {
		this.name = name;
	}*/
	
	/**
	 * add a room name rn of size size into the current venue
	 * @param String rn (roomname)
	 * @param String size
	 */
	
	public void addRoom(String rn, String size) {
		Room r = this.getRoom(rn);
		if (r != null) return;
		if (size.compareTo("small") == 0) {
			SmallRoom sr = new SmallRoom(rn);
			this.roomlist.add(sr);
			this.smallroom.add(sr);
		} else if (size.compareTo("medium") == 0) {
			MediumRoom mr = new MediumRoom(rn);
			this.roomlist.add(mr);
			this.mediumroom.add(mr);
		} else if (size.compareTo("large") == 0) {
			BigRoom br = new BigRoom(rn);
			this.roomlist.add(br);
			this.bigroom.add(br);
		}
	}
	
	/**
	 * Get the room by name
	 * @param String name
	 * @return a Room object, null as default
	 */
	
	private Room getRoom(String name) {
		for (Room rm : this.roomlist) {
			if (rm.getName().compareTo(name) == 0) {
				return rm;
			}
		}
		return null;
	}
	
	/**
	 * add the Request object to the requestlist 
	 * @param Request rq
	 */
	
	public void addRequest(Request rq) {
		if (rq == null) return;
		int i = rq.getSmall(), j = rq.getMedium(), k = rq.getBig();
		// Triple t = new Triple(rq.getSmall(), rq.getMedium(), rq.getBig());
		LocalDate start = rq.getStart();
		LocalDate end = rq.getEnd();
		for (SmallRoom room : smallroom) {
			if (i <= 0) break;
			if (room.couldRequest(start, end)) {
				room.addRequest(rq);
				i--;
			}
		}
		
		for (MediumRoom room : mediumroom) {
			if (j <= 0) break;
			if (room.couldRequest(start, end)) {
				room.addRequest(rq);
				j--;
			}
		}
		
		for (BigRoom room : bigroom) {
			if (k <= 0) break;
			if (room.couldRequest(start, end)) {
				room.addRequest(rq);
				k--;
			}
		}
		this.requestlist.put(rq.getId(), rq);
	}
	/**
	 * cancel the requestId
	 * @param String id
	 * remove the request id if it exists
	 */
	public void cancelRequest(String id) {
		if (this.requestlist.containsKey(id)) {
			for (Room room : roomlist) {
				room.cancelRequest(id);
			}
			this.requestlist.get(id).clear();
			this.requestlist.remove(id);
		}
	}
	
	/**
	 * Check if the request could be filled in the current venue
	 * @param String id
	 * @param LocalDate start
	 * @param LocalDate end
	 * @param int small
	 * @param int medium
	 * @param int large
	 * @return a boolean that if a request that fills 
	 */
	
	public boolean checkRequest(String id, LocalDate start, LocalDate end,
			int small, int medium, int large) {
		// Triple t = new Triple(small, medium, large);
		int i = small, j = medium, k = large;
		for (SmallRoom room : smallroom) {
			if (i <= 0) break;
			if (room.couldRequest(start, end)) {
				i--;
			}
		}
		
		for (MediumRoom room : mediumroom) {
			if (j <= 0) break;
			if (room.couldRequest(start, end)) {
				j--;
			}
		}
		
		for (BigRoom room : bigroom) {
			if (k <= 0) break;
			if (room.couldRequest(start, end)) {
				k--;
			}
		}
		return i == 0 && j == 0 && k == 0;
	}
	
	/**
	 * 
	 * @param String id
	 * @return an ArrayList of Rooms that has the request of request id id
	 */
	
	public ArrayList<Room> allRequestId(String id) {
		ArrayList<Room> ans = new ArrayList<Room>();
		for (Room room : this.roomlist) {
			if (room.containsRequest(id)) {
				ans.add(room);
			}
		}
		return ans;
	}
	
	/**
	 * list all the rooms in the current venue
	 * @return JSONArray of all the rooms and its status
	 */
	public JSONArray listRoom() {
		JSONArray result = new JSONArray();
		for (Room r : this.roomlist) {
			JSONObject roomresult = r.showStatus();
			result.put(roomresult);
		}
		return result;
	}
	
}