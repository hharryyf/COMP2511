/**
 *
 */
package unsw.venues;

import java.time.LocalDate;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONObject;
// import org.json.JSONTokener;

/**
 * Venue Hire System for COMP2511.
 *
 * A basic prototype to serve as the "back-end" of a venue hire system. Input
 * and output is in JSON format.
 *
 * @author Robert Clifton-Everest
 *
 */
public class VenueHireSystem {

    /**
     * Constructs a venue hire system. Initially, the system contains no venues,
     * rooms, or bookings.
     */
	ArrayList<Venue> venuelist;
	HashMap<String, Request> allrequest;
    public VenueHireSystem() {
        this.venuelist = new ArrayList<Venue>();
        this.allrequest = new HashMap<String, Request>();
    }
    
    /**
     * pass in a json object output the result of the command
     * @param JSONObject indicating the command
     */
    
    public void processCommand(JSONObject json) {
    	String id;
    	LocalDate start, end;
    	int small, medium, large;
    	JSONObject result;
        switch (json.getString("command")) {

		    case "room":
		        String venue = json.getString("venue");
		        String room = json.getString("room");
		        String size = json.getString("size");
		        addRoom(venue, room, size);
		        break;

		    case "request":
		        id = json.getString("id");
		        start = LocalDate.parse(json.getString("start"));
		        end = LocalDate.parse(json.getString("end"));
		        small = json.getInt("small");
		        medium = json.getInt("medium");
		        large = json.getInt("large");

		        result = request(id, start, end, small, medium, large);

		        System.out.println(result.toString(2));
		        break;
		    case "change":
		    	id = json.getString("id");
		        start = LocalDate.parse(json.getString("start"));
		        end = LocalDate.parse(json.getString("end"));
		        small = json.getInt("small");
		        medium = json.getInt("medium");
		        large = json.getInt("large");
		        result = change(id, start, end, small, medium, large);
		        
		        System.out.println(result.toString(2));
		    	break;
		    case "cancel":
		    	id = json.getString("id");
		    	result = cancel(id);
		    	
		    	System.out.println(result.toString(2));
		    	break;
		    case "list":
		    	id = json.getString("venue");
		    	JSONArray arr = list(id);
		    	
		    	System.out.println(arr);
		    	break;
		    	
		    default:
		    	break;
        }
    }
    
    /**
     * add a room of size size into 
     * @param String venue name
     * @param String room name
     * @param String size 
     * no return
     */
    
    private void addRoom(String venue, String room, String size) {
    	
        // TODO Process the room command
    	Venue v = this.getVenue(venue);
    	/*
    	 * if the search result is null then a new venue should
    	 * be created
    	 * */
    	if (v == null) {
    		v = new Venue(venue);
    		v.addRoom(room, size);
    		this.venuelist.add(v);
    	} else {
    		v.addRoom(room, size);
    	}
    }
    
    /**
     * get the venue according to its name
     * @param String venuename
     * @return a Venue object or null if the venue name doesn't exist
     */
    
    private Venue getVenue(String venue) {
    	for (Venue v : venuelist) {
    		if (v.getName().compareTo(venue) == 0) {
    			return v;
    		}
    	}
    	return null;
    }
    
    /**
     * Add a request to the first venue that's available
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     * @return the Venue that add the request, null as default
     */
    private Venue addRequest(String id, LocalDate start, LocalDate end, 
    		int small, int medium, int large) {
    	// if no venue can add the request return null
    	if (!couldRequest(id, start, end, small, medium, large)) {
    		return null;
    	}
    	// if the request id doesn't exist, instantiate a new request
    	// object and store it to the hash map
    	Request rq = allrequest.getOrDefault(id, new Request(id, start, end));
    	allrequest.put(id, rq);
    	// set the room number
    	rq.setSmall(small);
    	rq.setMedium(medium);
    	rq.setBig(large);
    	for (Venue v : this.venuelist) {
    		// check for the first venue that could fulfill the request
    		// return v and add the request rq to v
    		if (v.checkRequest(id, start, end, small, medium, large)) {
    			rq.setStart(start);
    			rq.setEnd(end);
    			v.addRequest(rq);
    			return v;
    		}
    	}
    	// a default return should never come here unless the implementation
    	// is incorrect
    	return null;
    }
    /**
     * 
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     * @return the venue indicating the venue that the request change to
     * return null if change fails
     */
    private Venue changeRequest(String id, LocalDate start, LocalDate end, 
    		int small, int medium, int large) {
    	// the request id doesn't exist, simply return null
    	if (!this.allrequest.containsKey(id)) return null;
    	// otherwise find the request
    	Request rq = this.allrequest.get(id);
    	// set the status to be 2, 2 means pending
    	rq.setStatus(2);
    	// check if we could request if so
    	if (couldRequest(id, start, end, small, medium, large)) {
    		// clear the request roomlist
    		rq.clear();
    		// cancel the request from the venue
    		for (Venue v : this.venuelist) {		
    			v.cancelRequest(id);
    		}
    		// find the first venue that could fill in the request
    		for (Venue v : this.venuelist) {
    			if (v.checkRequest(id, start, end, small, medium, large)) {
    				rq.setStart(start);
    				rq.setEnd(end);
    				rq.setStatus(1);
    				rq.setSmall(small);
    				rq.setMedium(medium);
    				rq.setBig(large);
    				v.addRequest(rq);
    				return v;
    			}
    		}
    		
    		// System.out.println("error");
    	}
    	// if we cannot change the request reset the status to be 1
    	// return the default null
    	rq.setStatus(1);
    	return null;
    }
    /**
     * Judge whether a request of start/end with (small, medium, large) number of 
     * rooms could be fulfilled
     * @param String id 
     * @param LocalDate start
     * @param LocalDate end
     * @param int small
     * @param int medium
     * @param int large
     * @return boolean value if the request could fill in at least 1 venue
     */
    private boolean couldRequest(String id, LocalDate start, LocalDate end, 
    		int small, int medium, int large) {
    	// check all the venues in the venuelist and see if
    	// the request could be added in, if so return true
    	// otherwise, return false
    	for (Venue v : this.venuelist) {
    		if (v.checkRequest(id, start, end, small, medium, large)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    /**
     * change the request of requestid to start/end date and small, medium, large
     * number of each type of room
     * @param String requestid
     * @param LocalDate start
     * @param LocalDate end
     * @param int small
     * @param int medium
     * @param int large
     * @return a JSONObject indicating the status of the change request
     */
    public JSONObject change(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
    	JSONObject result = new JSONObject();
    	Venue v = this.changeRequest(id, start, end, small, medium, large);
        String str = (v != null ? new String("success") : new String("rejected"));
        result.put("status", str);
        if (v == null) {
        	return result;
        }
        
        JSONArray roomarr = new JSONArray();
        String venuename = new String(v.getName());
        result.put("venue", venuename);
        ArrayList<Room> rooms = v.allRequestId(id);
        for (Room r : rooms) {
        	roomarr.put(r.getName());
        }
        result.put("rooms", roomarr);
        return result;
    }
    
    /**
     * 
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     * @return JSONObject indicating the status of this request
     */
    
    public JSONObject request(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
        JSONObject result = new JSONObject();

        // let v points to the Venue that the request should be added
        // null if no venue could fulfill this request
        Venue v = this.addRequest(id, start, end, small, medium, large);
        String str = (v != null ? new String("success") : new String("rejected"));
        result.put("status", str);
        // if v is null then the request fails return result directly
        if (v == null) {
        	return result;
        }
        // otherwise, look into the venue and check which room has
        // the booking id call the allRequestId method to the venue
        // to get the arraylist of the room associated with this request
        JSONArray roomarr = new JSONArray();
        String venuename = new String(v.getName());
        result.put("venue", venuename);
        ArrayList<Room> rooms = v.allRequestId(id);
        for (Room r : rooms) {
        	roomarr.put(r.getName());
        }
        //JSONArray rooms = new JSONArray();
        //rooms.put("Penguin");
        //rooms.put("Hippo");

        //result.put("rooms", rooms);
        
        // return the result for a success request command
        result.put("rooms", roomarr);
        return result;
    }
    
    /**
     * cancel a request given the request id
     * @param String id (requestid)
     * @return a JSONObject indicating the status of the cancel
     */
    public JSONObject cancel(String id) {
    	JSONObject result = new JSONObject();
    	// if the request id doesn't exist simply return rejected
    	if (!this.allrequest.containsKey(id)) {
    		result.put("status","rejected");
    	} else {
    		// all venue remove the request id
    		for (Venue v : this.venuelist) {
    			v.cancelRequest(id);
    		}
    		// the system remove the request id
    		this.allrequest.remove(id);
    		result.put("status", "success");
    	}
    	return result;
    }
    /**
     * list all the rooms and all the reserve status in the rooms
     * given a venueid
     * @param String venue
     * @return a JSONArray as a collections of JSONObject
     */
    public JSONArray list(String venue) {
    	JSONArray result = new JSONArray();
    	for (Venue v : this.venuelist) {
    		if (v.getName().compareTo(venue) == 0) {
    			result = v.listRoom();
    			break;
    		}
    	}
    	return result;
    }
    
    public static void main(String[] args) {
        VenueHireSystem system = new VenueHireSystem();

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (!line.trim().equals("")) {
                JSONObject command = new JSONObject(line);
                system.processCommand(command);
            }
        }
        sc.close();
    }


}
