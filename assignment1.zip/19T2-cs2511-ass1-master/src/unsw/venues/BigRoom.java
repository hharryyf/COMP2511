package unsw.venues;
 
public class BigRoom extends Room {
	public BigRoom(String name) {
		super(name);
	}
}
