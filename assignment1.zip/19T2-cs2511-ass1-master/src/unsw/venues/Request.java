package unsw.venues;

import java.time.LocalDate;
import java.util.*;

public class Request {
	private int small;
	private int medium;
	private int big;
	private String id;
	private int status;
	private LocalDate start;
	private LocalDate end;
	private ArrayList<SmallRoom> smallroom;
	private ArrayList<MediumRoom> mediumroom;
	private ArrayList<BigRoom> bigroom;
	public Request(String id, LocalDate st, LocalDate ed) {
		this.id = id;
		this.start = st;
		this.end = ed;
		this.status = 1;
		this.smallroom = new ArrayList<SmallRoom>();
		this.mediumroom = new ArrayList<MediumRoom>();
		this.bigroom = new ArrayList<BigRoom>();
		this.small = 0;
		this.big = 0;
		this.medium = 0;
	}
	
	public int getSmall() {
		return small;
	}

	public void setSmall(int small) {
		this.small = small;
	}

	public int getMedium() {
		return medium;
	}

	public void setMedium(int medium) {
		this.medium = medium;
	}

	public int getBig() {
		return big;
	}

	public void setBig(int big) {
		this.big = big;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getId() {
		return id;
	}
	/*
	public void setId(String id) {
		this.id = id;
	}*/
	
	public LocalDate getStart() {
		return start;
	}
	
	public void setStart(LocalDate start) {
		this.start = start;
	}
	
	public LocalDate getEnd() {
		return end;
	}
	
	public void setEnd(LocalDate end) {
		this.end = end;
	}
	
	public void clear() {
		smallroom.clear();
		bigroom.clear();
		mediumroom.clear();
	}
	
	public void addSmallRoom(SmallRoom sr) {
		smallroom.add(sr);
	}
	
	public void addMediumRoom(MediumRoom mr) {
		mediumroom.add(mr);
	}
	
	public void addBigRoom(BigRoom br) {
		bigroom.add(br);
	}
	
}
