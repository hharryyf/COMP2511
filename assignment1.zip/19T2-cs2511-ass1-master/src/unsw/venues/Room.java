package unsw.venues;

import java.time.LocalDate;
import java.util.*;

import org.json.JSONArray;

import org.json.JSONObject;
// import org.json.JSONTokener;

public class Room {
	private String name;
	private LinkedList<Request> reserve;
	public Room(String name) {
		this.name = name;
		this.reserve = new LinkedList<Request>();
	}
	
	public String getName() {
		return name;
	}
	/*
	public void setName(String name) {
		this.name = name;
	}
	*/
	public void addRequest(Request rq) {
		this.reserve.add(rq);
	}
	
	public void cancelRequest(String id) {
		Iterator<Request> it = this.reserve.iterator();
		// System.out.println(this.name + " cancels " + id);
		while (it.hasNext()) {
			String str = it.next().getId();
			if (str.compareTo(id) == 0) {
				it.remove();
			}
		}
	}
	/**
	 * 
	 * @param start
	 * @param end
	 * @return a boolean value indicating whether the start and end
	 *  time could fill in the room
	 */
	public boolean couldRequest(LocalDate start, LocalDate end) {
		Iterator<Request> it = this.reserve.iterator();
		while (it.hasNext()) {
			Request rq = it.next();
			if (rq.getStatus() == 1 && rq.getStart().compareTo(start) <= 0
					&& rq.getEnd().compareTo(start) >= 0) {
				//System.out.println(start + "--" + end + " contradicts " + rq.getStart() + "--" + rq.getEnd());
				return false;
			}
			
			if (rq.getStatus() == 1 && rq.getStart().compareTo(end) <= 0
					&& rq.getEnd().compareTo(end) >= 0) {
				// System.out.println(start + "--" + end + " contradicts " + rq.getStart() + "--" + rq.getEnd());
				return false;
			}
			
			if (rq.getStatus() == 1 && rq.getStart().compareTo(start) >= 0
					&& rq.getStart().compareTo(end) <= 0) {
				// System.out.println(start + "--" + end + " contradicts " + rq.getStart() + "--" + rq.getEnd());
				return false;
			}
			
			if (rq.getStatus() == 1 && rq.getEnd().compareTo(start) >= 0
					&& rq.getEnd().compareTo(end) <= 0) {
				// System.out.println(start + "--" + end + " contradicts " + rq.getStart() + "--" + rq.getEnd());
				return false;
			}
			
		}
		
		// System.out.println("the starting time " + start);
		return true;
	}
	/**
	 * check if a room contains a request of the given id
	 * @param String id
	 * @return boolean value yes/no
	 */
	public boolean containsRequest(String id) {
		Iterator<Request> it = this.reserve.iterator();
		while (it.hasNext()) {
			String str = it.next().getId();
			if (str.compareTo(id) == 0) {
				return true;
			}
		}
		return false;
	}
	
	public JSONObject showStatus() {
		JSONObject result = new JSONObject();
		result.put("room", this.getName());
		JSONArray arr = new JSONArray();
		List<Request> ans = new ArrayList<Request>();
		for (Request rq : this.reserve) {
			ans.add(rq);
		}
		
		Collections.sort(ans, (Request rq1, Request rq2)->{
			return rq1.getStart().compareTo(rq2.getStart());
		});
		
		for (Request rq : ans) {
			JSONObject jb = new JSONObject();
			jb.put("id", rq.getId());
			jb.put("start", rq.getStart());
			jb.put("end", rq.getEnd());
			arr.put(jb);
		}
		result.put("reservations", arr);
		return result;
	}
}
