package unsw.venues;

public class SmallRoom extends BigRoom {
	SmallRoom(String name) {
		super(name);
	}
}
