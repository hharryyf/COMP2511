package unsw.venues;

public class MediumRoom extends Room {
	public MediumRoom(String name) {
		super(name);
	}
}
