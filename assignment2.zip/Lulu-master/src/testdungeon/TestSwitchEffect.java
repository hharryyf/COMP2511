package testdungeon;

import unsw.dungeon.model.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSwitchEffect {
	
	/*
	 * test whether the judge could set the enemy to stop
	 * .....
	 * ...P.
	 * ...B.
	 * ...S.
	 * ...Ee
	 * 
	 * */
	
	@Test
	void test() {
		Dungeon dungeon = new Dungeon(5,5);
		Switch switches = new Switch(3, 3);
		Boulder boulder = new Boulder(3,2);
		dungeon.addEntity(boulder);
		dungeon.addEntity(switches);
		dungeon.addSwich(switches);
		dungeon.addBoulder(boulder);
		Enemy enemy = new Enemy(dungeon, 3, 4);
		Player player = new Player(dungeon, 3, 1);
		Judge judge = new Judge(dungeon);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		dungeon.addEnemy(enemy);
		dungeon.addEntity(enemy);
		Goal goal = new BasicExitGoal(dungeon);
		player.setGoal(goal);
		Exit exit = new Exit(4,4);
		dungeon.addEntity(exit);
		dungeon.addExit(exit);
		player.moveDown();
		judge.judgeRound();
		judge.updateBoard();
		dungeon.enemyMove();
		judge.judgeRound();
		judge.updateBoard();
		assertEquals(switches.isTriggers(), true);
		assertEquals(enemy.isMovable(), false);
		assertEquals(enemy.getX(), 3);
		assertEquals(enemy.getY(), 4);
	}
	

	/*
	 * test whether the judge could set the enemy to stop and move after 1 stop round
	 * .....
	 * ...P.
	 * ...B.
	 * ...S.
	 * ...Ee
	 * 
	 * */
	
	@Test
	void testrestart() {
		Dungeon dungeon = new Dungeon(5,5);
		Switch switches = new Switch(3, 3);
		Boulder boulder = new Boulder(3,2);
		dungeon.addEntity(boulder);
		dungeon.addEntity(switches);
		dungeon.addSwich(switches);
		dungeon.addBoulder(boulder);
		Enemy enemy = new Enemy(dungeon, 3, 4);
		Player player = new Player(dungeon, 3, 1);
		Judge judge = new Judge(dungeon);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		dungeon.addEnemy(enemy);
		dungeon.addEntity(enemy);
		Goal goal = new BasicExitGoal(dungeon);
		player.setGoal(goal);
		Exit exit = new Exit(4,4);
		dungeon.addEntity(exit);
		dungeon.addExit(exit);
		player.moveDown();
		judge.judgeRound();
		judge.updateBoard();
		dungeon.enemyMove();
		judge.judgeRound();
		judge.updateBoard();
		assertEquals(switches.isTriggers(), true);
		assertEquals(enemy.isMovable(), false);
		assertEquals(enemy.getX(), 3);
		assertEquals(enemy.getY(), 4);
		player.moveRight();
		judge.judgeRound();
		judge.updateBoard();
		dungeon.enemyMove();
		judge.judgeRound();
		judge.updateBoard();
		assertEquals(switches.isTriggers(), true);
		assertEquals(enemy.isMovable(), true);
		assertEquals(enemy.getX(), 4);
		assertEquals(enemy.getY(), 4);
	}
}
