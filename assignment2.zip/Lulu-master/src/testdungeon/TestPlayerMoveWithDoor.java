package testdungeon;

import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPlayerMoveWithDoor {

	@Test
	void test() {
		/*  test the player, make sure it will not walk to the door without a key
		 * #### ###
		 * #      #
		 * #p     #
		 * # d     
		 * ########
		 * 
		 */
		
		Dungeon dungeon = new Dungeon(8, 5);
		Player player = new Player(dungeon, 1, 2);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		Doors door = new Doors(2, 3, 1);
		dungeon.setPlayer(player);
		dungeon.addEntity(door);
		dungeon.addDoor(door);
		// check the success addition of the door
		assertEquals(dungeon.getClosedDoor(2, 3), door);
		player.moveDown();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		// should have no effect since it is a wall
		player.moveLeft();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		// should have no effect since it is a closed door
		player.moveRight();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		// should have no effect since it is a closed door
		player.moveUp();
		player.moveRight();
		player.moveDown();
		player.moveDown();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 2);
		player.moveRight();
		player.moveDown();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 3);
		// should have no effect since it is a closed door
		player.moveLeft();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 3);
	}

}
