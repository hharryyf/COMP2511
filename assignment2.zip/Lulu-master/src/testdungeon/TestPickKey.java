package testdungeon;

import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Key;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPickKey {

	
		/*
		 * basically test whether the user can pickup a key or not, and if it can successfully open the
		 * corresponding door 
		 * #### ###
		 * #p     #
		 * # #    #
		 * #2d 1    
		 * ########
		 * 
		 */
		
	/*
	 * test whether the user can pickup the key and open the corresponding door
	 */
	@Test
	void testPickOpen() {
		Dungeon dungeon = new Dungeon(8, 5);
		Player player = new Player(dungeon, 1, 1);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		Wall wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		
		Doors door = new Doors(2, 3, 1);
		dungeon.setPlayer(player);
		dungeon.addEntity(door);
		dungeon.addDoor(door);
		// check the success addition of the door
		assertEquals(dungeon.getClosedDoor(2, 3), door);
		
		Key key1 = new Key(4, 3, 1);
		Key key2 = new Key(1, 3, 2);
		dungeon.addEntity(key1);
		dungeon.addKey(key1);
		dungeon.addEntity(key2);
		dungeon.addKey(key2);
		assertEquals(dungeon.getClosedDoor(2, 3), door);
		player.moveRight();
		player.moveRight();
		player.moveRight();
		player.moveDown();
		player.moveDown();
		player.moveLeft();
		player.moveLeft();
		player.moveLeft();
		// cannot move into the door since no key
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 3);
		player.moveRight();
		player.pickup();
		// success to pickup
		assertEquals(player.hasKey(), true);
		player.moveLeft();
		player.moveLeft();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 3);
		// the door is automatically opened, the key is lost
		assertEquals(player.hasKey(), false);
		assertEquals(door.isOpen(), true);
		assertEquals(dungeon.getClosedDoor(2, 3), null);
		player.moveLeft();
		player.pickup();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		assertEquals(key2.getshouldDie(), true);
		player.moveRight();
		player.moveRight();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 3);
		dungeon.updateEntityStates();
		assertEquals(player.hasKey(), true);
		assertEquals(dungeon.getKey().isEmpty(), true);
	}
	/*
	 * test whether the user can only have 1 key in hand and cannot open the door which is not
	 * controlled by the key
	 */
	@Test
	void testNoDup() {
		Dungeon dungeon = new Dungeon(8, 5);
		Player player = new Player(dungeon, 1, 1);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		Wall wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		
		Doors door = new Doors(2, 3, 1);
		dungeon.setPlayer(player);
		dungeon.addEntity(door);
		dungeon.addDoor(door);
		// check the success addition of the door
		assertEquals(dungeon.getClosedDoor(2, 3), door);
		
		Key key1 = new Key(4, 3, 1);
		Key key2 = new Key(1, 3, 2);
		dungeon.addEntity(key1);
		dungeon.addKey(key1);
		dungeon.addEntity(key2);
		dungeon.addKey(key2);
		player.moveDown();
		player.moveDown();
		player.pickup();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 3);
		assertEquals(key2.getshouldDie(), true);
		assertEquals(door.isOpen(), false);
		player.moveUp();
		player.moveUp();
		player.moveRight();
		player.moveRight();
		player.moveRight();
		player.moveDown();
		player.moveDown();
		player.pickup();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 3);
		assertEquals(key1.getshouldDie(), false);
		assertEquals(player.hasKey(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getKey(1, 3), null);
		assertEquals(dungeon.getKey(4, 3), key1);
		assertEquals(dungeon.getClosedDoor(2, 3), door);
	}

}
