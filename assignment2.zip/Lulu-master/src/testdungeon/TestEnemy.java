package testdungeon;

import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestEnemy {

	private Dungeon dungeon;
	private Enemy enemy1, enemy2, enemy3;
	private Player player;
	@Test
	void test() {
		dungeon = new Dungeon(10, 10);
		int i, j;
		Wall wall;
		for (i = 0 ; i < 10; i++) {
			for (j = 0 ; j < 10; j++) {
				if (i == 0 || j == 0 || i == 9 || j == 9) {
					wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		wall = new Wall(6, 8);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(7, 7);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		/* for this maze only has a player we can see that the enemy's position
		 * using the greedy search after a move should be 7, 8
		 * but the enemy's movement after executing A* algorithm should be 8, 7 
		 * ##########
		 * #      #p#
		 * #        #
		 * #        #
		 * #        #
		 * #        #
		 * #       ##
		 * #      # #
		 * #       E#
		 * ##########
		 * 
		 */
		
		player = new Player(dungeon, 1, 8);
		dungeon.setPlayer(player);
		enemy1 = new Enemy(dungeon, 8, 8);
		dungeon.addEnemy(enemy1);
		testGreedy();
		testAstar();
		testStateChange();
	}
	// this piece of code test the enemy movement of the greedy search, check if greedy could cause
	// infinite loop
	void testGreedy() {
		enemy1.move();
		assertEquals(enemy1.getX(), 7);
		assertEquals(enemy1.getY(), 8);
		enemy1.move();
		assertEquals(enemy1.getX(), 8);
		assertEquals(enemy1.getY(), 8);
	}
	
	// this piece of code test the enemy movement of the A* search
	void testAstar() {
		int[][] expected = {{8, 7}, {8, 6}, {7, 6}, {6, 6}, {6, 7}, {5, 7}, {5, 8}, {4, 8}, {3, 8}, {2, 8}, {1, 8}};
		enemy2 = new Enemy(dungeon, 8, 8, 1);
		dungeon.addEnemy(enemy2);
		for (int i = 0 ; i < expected.length; i++) {
			enemy2.move();
			assertEquals(enemy2.getX(), expected[i][0]);
			assertEquals(enemy2.getY(), expected[i][1]);
		}
		
		assertEquals(enemy2.getX(), player.getX());
		assertEquals(enemy2.getY(), player.getY());
	}
	
	// test the state pattern of the enemy, check whether the stop could switch to move
	void testStateChange() {
		enemy3 = new Enemy(dungeon, 8, 8, 0);
		dungeon.addEnemy(enemy3);
		enemy3.setStop();
		enemy3.setPause(4);
		assertEquals(enemy3.isMovable(), false);
		enemy3.move();
		assertEquals(enemy3.isMovable(), false);
		assertEquals(enemy3.getPause(), 3);
		enemy3.setMove();
		assertEquals(enemy3.isMovable(), true);
		assertEquals(enemy3.getPause(), 0);
	}
}
