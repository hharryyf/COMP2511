package testdungeon;

import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.UnlitBomb;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPutBomb {

	@Test
	void test() {
		/*
		 * this is a test for the put bomb
		 * 1. the bomb is put on the ground
		 * 2. the bomb is wipped out from the map
		 * 3. an active bomb is added to the dungeon
		 * #######
		 * #p    #
		 * #  B  #
		 * #     #
		 * #######
		 */
		Dungeon dungeon = new Dungeon(7, 5);
		Player player = new Player(dungeon, 1, 1);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		Bomb bomb = new UnlitBomb(dungeon, 3, 2);
		dungeon.addEntity(bomb);
		dungeon.addBomb(bomb);
		player.moveRight();
		player.moveRight();
		player.moveDown();
		player.pickup();
		assertEquals(player.hasBomb(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 0);
		assertEquals(dungeon.getBombs().size(), 0);
		assertEquals(bomb.getshouldDie(), true);
		player.moveRight();
		player.putBomb();
		assertEquals(player.hasBomb(), false);
		assertEquals(dungeon.getActiveBombs().size(), 1);
		dungeon.reduceBomb();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 1);
		dungeon.reduceBomb();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 1);
		dungeon.reduceBomb();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 1);
		dungeon.reduceBomb();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 1);
		dungeon.reduceBomb();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getActiveBombs().size(), 0);
		assertEquals(player.getshouldDie(), true);
	}

}
