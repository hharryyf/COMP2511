package testdungeon;

import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Potion;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPotion {

	@Test
	void test() {
		/*
		 * mainly this unit test tests the pickup potion functionality
		 * 1. the potion will lasts for 4 rounds
		 * 2. the will walk away from the user
		 * p..I....|
		 * .......E|
		 */
		Dungeon dungeon = new Dungeon(8, 2);
		Player player = new Player(dungeon, 0, 0);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Potion potion = new Potion(3, 0);
		dungeon.addEntity(potion);
		dungeon.addPotion(potion);
		// provide an intellegence enemy
		Enemy enemy = new Enemy(dungeon, 7, 1, 1);
		dungeon.addEnemy(enemy);
		dungeon.addEntity(enemy);
		player.moveRight();
		enemy.move();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		assertEquals(enemy.getX(), 7);
		assertEquals(enemy.getY(), 0);
		// the user is on the potion
		player.moveRight();
		enemy.move();
		player.moveRight();
		enemy.move();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 0);
		assertEquals(enemy.getX(), 5);
		assertEquals(enemy.getY(), 0);
		assertEquals(player.hasPotion(), false);
		player.pickup();
		assertEquals(player.hasPotion(), true);
		player.reducePotion(); // 4
		enemy.move();
		assertEquals(enemy.getX(), 5);
		assertEquals(enemy.getY(), 1);
		player.moveRight(); 
		assertEquals(player.hasPotion(), true);
		player.reducePotion(); // 3
		enemy.move();
		assertEquals(enemy.getX(), 6);
		assertEquals(enemy.getY(), 1);
		player.moveRight(); 
		assertEquals(player.hasPotion(), true);
		player.reducePotion(); // 2
		enemy.move();
		assertEquals(enemy.getX(), 7);
		assertEquals(enemy.getY(), 1);
		player.moveRight(); 
		assertEquals(player.hasPotion(), true);
		player.reducePotion(); // 1
		enemy.move();
		assertEquals(enemy.getX(), 7);
		assertEquals(enemy.getY(), 0);
		player.moveRight();
		player.reducePotion();
		assertEquals(enemy.getshouldDie(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getPotion().size(), 0);
		assertEquals(player.hasPotion(), false);
	}

}
