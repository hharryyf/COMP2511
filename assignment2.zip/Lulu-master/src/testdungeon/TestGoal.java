package testdungeon;

import unsw.dungeon.model.BasicBoulderGoal;
import unsw.dungeon.model.BasicEnemyGoal;
import unsw.dungeon.model.BasicExitGoal;
import unsw.dungeon.model.BasicTreasureGoal;
import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.CombinationGoal;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Goal;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Switch;
import unsw.dungeon.model.Sword;
import unsw.dungeon.model.UnlitBomb;

import static org.junit.jupiter.api.Assertions.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

class TestGoal {
	
	
		/*
		 * test the composite pattern of goal
		 * ......
		 * .pS...
		 * .BWE..
		 */
	@Test
	void testSingle() {
		/*
		 * ...E
		 * ..PB
		 */
		Dungeon dungeon = new Dungeon(4, 2);
		Enemy enemy = new Enemy(dungeon, 3, 0);
		dungeon.addEnemy(enemy);
		dungeon.addEntity(enemy);
		Player player = new Player(dungeon, 2, 1);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Bomb bomb = new UnlitBomb(dungeon, 3, 1);
		dungeon.addBomb(bomb);
		dungeon.addEntity(bomb);
		
		String str = "{\"goal\": \"enemies\"}";
		JSONObject jb = new JSONObject(str);
		Goal goal = parseGoal(dungeon, jb);
		player.setGoal(goal);
		dungeon.updateGoal();
		player.moveRight();
		player.pickup();
		dungeon.updateEntityStates();
		player.putBomb();
		dungeon.updateEntityStates();
		player.moveLeft();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		player.moveLeft();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		// goal.display();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		// goal.display();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		// goal.display();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		// goal.display();
		dungeon.updateEntityStates();
		assertEquals(player.getshouldDie(), false);
		assertEquals(bomb.getshouldDie(), true);
		assertEquals(dungeon.getActiveBombs().size(), 0);
		assertEquals(enemy.getshouldDie(), true);
		assertEquals(player.completeGoal(), true);
	}
	
	@Test
	void testOr() {
		Dungeon dungeon;
		Player player;
		dungeon = new Dungeon(6, 3);
		Sword sword = new Sword(2, 1);
		player = new Player(dungeon, 1, 1);
		Enemy enemy = new Enemy(dungeon, 3, 2);
		Boulder boulder = new Boulder(1, 2);
		Switch sw = new Switch(2, 2);
		dungeon.addEntity(sw);
		dungeon.addEntity(player);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);
		dungeon.addBoulder(boulder);
		dungeon.setPlayer(player);
		dungeon.addEnemy(enemy);
		dungeon.addBoulder(boulder);
		dungeon.addSwich(sw);
		dungeon.addSword(sword);
		String str = " { \"goal\": \"OR\", \"subgoals\": [{ \"goal\": \"enemies\"},{\"goal\": \"boulders\"}]}";
		JSONObject jb = new JSONObject(str);
		Goal goal = parseGoal(dungeon, jb);
		player.setGoal(goal);
		dungeon.updateGoal();
		player.moveRight();
		player.pickup();
		player.moveDown();
		player.moveRight();
		dungeon.updateGoal();
		// should work since it is a or relationship
		assertEquals(player.completeGoal(), true);
		player.moveUp();
		player.moveLeft();
		player.moveLeft();
		player.moveLeft();
		player.moveDown();
		player.moveRight();
		dungeon.updateGoal();
		// now the goal should work, since all of the goals are completed
		assertEquals(player.completeGoal(), true);
	}
	
	@Test
	void testAnd() {
		Dungeon dungeon;
		Player player;
		dungeon = new Dungeon(6, 3);
		Sword sword = new Sword(2, 1);
		player = new Player(dungeon, 1, 1);
		Enemy enemy = new Enemy(dungeon, 3, 2);
		Boulder boulder = new Boulder(1, 2);
		Switch sw = new Switch(2, 2);
		dungeon.addEntity(sw);
		dungeon.addEntity(player);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);
		dungeon.addBoulder(boulder);
		dungeon.setPlayer(player);
		dungeon.addEnemy(enemy);
		dungeon.addBoulder(boulder);
		dungeon.addSwich(sw);
		dungeon.addSword(sword);
		String str = " { \"goal\": \"AND\", \"subgoals\": [{ \"goal\": \"enemies\"},{\"goal\": \"boulders\"}]}";
		JSONObject jb = new JSONObject(str);
		Goal goal = parseGoal(dungeon, jb);
		player.setGoal(goal);
		dungeon.updateGoal();
		player.moveRight();
		player.pickup();
		player.moveDown();
		player.moveRight();
		dungeon.updateGoal();
		assertEquals(player.completeGoal(), false);
		player.moveUp();
		player.moveLeft();
		player.moveLeft();
		player.moveLeft();
		player.moveDown();
		player.moveRight();
		dungeon.updateGoal();
		// now the goal should work, since all of the goals are completed
		assertEquals(player.completeGoal(), true);
		player.moveRight();
		dungeon.updateGoal();
		// now the goal should not work, since the switch is powered off
		assertEquals(player.completeGoal(), false);
	}
	
	private Goal parseGoal(Dungeon dungeon, JSONObject jb) {
    	if (jb.getString("goal").compareTo("AND") == 0) {
    		CombinationGoal goal = new CombinationGoal(dungeon, true);
    		JSONArray arr = jb.getJSONArray("subgoals");
    		for (int i = 0 ; i < arr.length(); i++) {
    			goal.addSubgoal(parseGoal(dungeon, arr.getJSONObject(i)));
    		}
    		return goal;
    	} else if (jb.getString("goal").compareTo("OR") == 0) {
    		CombinationGoal goal = new CombinationGoal(dungeon, false);
    		JSONArray arr = jb.getJSONArray("subgoals");
    		for (int i = 0 ; i < arr.length(); i++) {
    			goal.addSubgoal(parseGoal(dungeon, arr.getJSONObject(i)));
    		}
    		return goal;
    	} else if (jb.getString("goal").compareTo("boulders") == 0) {
    		return new BasicBoulderGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("enemies") == 0) {
    		return new BasicEnemyGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("treasure") == 0) {
    		return new BasicTreasureGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("exit") == 0) {
    		return new BasicExitGoal(dungeon);
    	}
    	return null;
    }

}
