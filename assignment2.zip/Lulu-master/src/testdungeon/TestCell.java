package testdungeon;

import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Switch;
import unsw.dungeon.model.Sword;
import unsw.dungeon.model.Wall;
import unsw.dungeon.model.UnlitBomb;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCell {
	private Dungeon dungeon;
	private Player player;
	@Test
	void test() {
		/*
		 * this is a test case that mainly test whether a cell in the dungeon is empty or not
		 * to make sure the automatically push boulder functionality could be fulfilled
		 * #### ###
		 * #p  B D#
		 * # #    #
		 * #S W  B
		 * ########
		 */
		dungeon = new Dungeon(8, 5);
		player = new Player(dungeon, 1, 1);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		Wall wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		Sword sword = new Sword(1, 3);
		dungeon.addEntity(sword);
		dungeon.addSword(sword);
		Bomb b = new UnlitBomb(dungeon, 6, 3);
		dungeon.addBomb(b);
		dungeon.addEntity(b);
		Boulder bd = new Boulder(4, 1);
		dungeon.addBoulder(bd);
		dungeon.addEntity(bd);
		Switch sw = new Switch(3, 3);
		dungeon.addSwich(sw);
		dungeon.addEntity(sw);
		Doors door = new Doors(6, 1, 1);
		dungeon.addDoor(door);
		dungeon.addEntity(door);
		assertEquals(dungeon.cellEmpty(0, 0), false);
		testWall();
		testInvalid();
		testDoor();
		testSwitch();
		testBoulder();
		testBomb();
	}
	
	void testEmpty() {
		assertEquals(dungeon.cellEmpty(3, 1), true);
		assertEquals(dungeon.cellEmpty(7, 3), true);
	}
	
	void testPlayer() {
		assertEquals(dungeon.cellEmpty(1, 1), false);
	}
	
	void testBomb() {
		assertEquals(dungeon.cellEmpty(6, 3), false);
	}
	
	void testBoulder() {
		assertEquals(dungeon.cellEmpty(4, 1), false);
	}
	
	void testSwitch() {
		assertEquals(dungeon.cellEmpty(3, 3), true);
	}
	
	void testWall() {
		assertEquals(dungeon.cellEmpty(0, 0), false);
		assertEquals(dungeon.cellEmpty(0, 1), false);
		assertEquals(dungeon.cellEmpty(0, 2), false);
		assertEquals(dungeon.cellEmpty(0, 3), false);
		assertEquals(dungeon.cellEmpty(0, 4), false);
		assertEquals(dungeon.cellEmpty(1, 0), false);
		assertEquals(dungeon.cellEmpty(1, 4), false);
		assertEquals(dungeon.cellEmpty(2, 4), false);
		assertEquals(dungeon.cellEmpty(2, 0), false);
	}
	
	void testInvalid() {
		assertEquals(dungeon.cellEmpty(-1, 2), false);
		assertEquals(dungeon.cellEmpty(8, 2), false);
		assertEquals(dungeon.cellEmpty(2, 5), false);
		assertEquals(dungeon.cellEmpty(1, -1), false);
	}
	
	void testDoor() {
		assertEquals(dungeon.cellEmpty(6, 1), false);
		Doors dr = dungeon.getClosedDoor(6, 1);
		if (dr != null) {
			dr.open();
		}
		assertEquals(dungeon.cellEmpty(6, 1), true);
	}
}
