package testdungeon;

import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Switch;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBoulder {

	/*
	* this unit test, tests the push boulder functionality
	* see whether the boulder can be pushed in the following cases
	* 1. cannot be pushed when the boulder will be pushed out of the cell
	* 2. cannot be pushed when the there's something in front of the boulder
	* 3. otherwise success
	*/
	
	@Test
	void testSwitch() {
		/*
		 * test:
		 * 1. the boulder can trigger the switch
		 * 2. the boulder can!! move onto the switch
		 * 
		 * PB..S.|
		 * ......|
		 */
		Dungeon dungeon = new Dungeon(6, 2);
		Player player = new Player(dungeon, 0, 0);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Boulder boulder = new Boulder(1, 0);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		Switch sw = new Switch(4, 0);
		dungeon.addSwich(sw);
		dungeon.addEntity(sw);
		player.moveRight();
		player.moveRight();
		player.moveRight();
		dungeon.updateGoal();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 4);
		assertEquals(boulder.getY(), 0);
		assertEquals(sw.isTriggers(), true);
		// move away to make sure the switch is untriggered
		player.moveRight();
		dungeon.updateGoal();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 5);
		assertEquals(boulder.getY(), 0);
		assertEquals(sw.isTriggers(), false);
		assertEquals(dungeon.getSwitch(4, 0), sw);
	}
	
	@Test
	void testOpenDoor() {
		/*
		 * test whether the boulder can be pushed through a open door
		 * pB.d.|
		 * .....|
		 */
		Dungeon dungeon = new Dungeon(5, 2);
		Player player = new Player(dungeon, 0, 0);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Boulder boulder = new Boulder(1, 0);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		Doors door = new Doors(3, 0, 1);
		dungeon.addDoor(door);
		dungeon.addEntity(door);
		player.moveRight();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 2);
		assertEquals(boulder.getY(), 0);
		// cannot go through a door if it is closed
		player.moveRight();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 2);
		assertEquals(boulder.getY(), 0);
		door.open();
		player.moveRight();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 3);
		assertEquals(boulder.getY(), 0);
		player.moveRight();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 4);
		assertEquals(boulder.getY(), 0);
		player.moveRight();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 4);
		assertEquals(boulder.getY(), 0);
	}
	
	@Test
	void testDirection() {
		/*
		 * the boulder should only be pushed on the direction the user move
		 * and not out of the border
		 * pB...|
		 * .....|
		 */
		Dungeon dungeon = new Dungeon(5, 2);
		Player player = new Player(dungeon, 0, 0);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Boulder boulder = new Boulder(1, 0);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		player.moveDown();
		assertEquals(boulder.getX(), 1);
		assertEquals(boulder.getY(), 0);
		player.moveRight();
		assertEquals(boulder.getX(), 1);
		assertEquals(boulder.getY(), 0);
		player.moveUp();
		assertEquals(boulder.getX(), 1);
		assertEquals(boulder.getY(), 0);
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 1);
		player.moveRight();
		player.moveUp();
		player.moveLeft();
		assertEquals(boulder.getX(), 0);
		assertEquals(boulder.getY(), 0);
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		player.moveLeft();
		assertEquals(boulder.getX(), 0);
		assertEquals(boulder.getY(), 0);
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		boulder = new Boulder(1, 1);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		player.moveDown();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 0);
		assertEquals(boulder.getX(), 1);
		assertEquals(boulder.getY(), 1);
	}
	
	@Test
	void testSuccess() {
		/*
		 * the boulder should be pushed in this case
		 * ####
		 * #pB  
		 * ####
		 */
		Dungeon dungeon = new Dungeon(4, 3);
		Player player = new Player(dungeon, 1, 1);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		int i, j;
		Wall wall;
		for (i = 0 ; i < 4; i++) {
			for (j = 0 ; j < 3; j++) {
				if (i == 0 || i == 3 || j == 0 || j == 3) {
					if (i != 3 || j != 1) {
						wall = new Wall(i, j);
						dungeon.addWall(wall);
						dungeon.addEntity(wall);
					}
				}
			}
		}
		
		Boulder boulder = new Boulder(2, 1);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		player.moveRight();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 1);
		assertEquals(boulder.getX(), 3);
		assertEquals(boulder.getY(), 1);
		assertEquals(dungeon.getBoulder(2, 1), null);
		assertEquals(dungeon.getBoulder(3, 1), boulder);
	}
	
	@Test
	void testNonEmpty() {
		/*
		 * the boulder should be pushed in this case
		 * ####
		 * #Bp  
		 * ####
		 */
		Dungeon dungeon = new Dungeon(4, 3);
		Player player = new Player(dungeon, 2, 1);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		int i, j;
		Wall wall;
		for (i = 0 ; i < 4; i++) {
			for (j = 0 ; j < 3; j++) {
				if (i == 0 || i == 3 || j == 0 || j == 3) {
					if (i != 3 || j != 1) {
						wall = new Wall(i, j);
						dungeon.addWall(wall);
						dungeon.addEntity(wall);
					}
				}
			}
		}
		
		Boulder boulder = new Boulder(1, 1);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		player.moveRight();
		player.moveLeft();
		player.moveLeft();
		assertEquals(dungeon.getBoulder(1, 1), boulder);
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 1);
	}
}
