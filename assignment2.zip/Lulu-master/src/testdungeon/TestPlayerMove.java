package testdungeon;

import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPlayerMove {
	
	@Test
	void test() {
		/* the most basic test for the player, make sure it will not walk out of the boundary
		 * or wall into the wall
		 * #### ###
		 * #      #
		 * #p     #
		 * #      
		 * ########
		 * 
		 */
		Dungeon dungeon = new Dungeon(8, 5);
		Player player = new Player(dungeon, 1, 2);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		dungeon.setPlayer(player);
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 2);
		player.moveLeft();
		assertEquals(player.getX(), 1);
		assertEquals(player.getY(), 2);
		player.moveRight();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 2);
		player.moveUp();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 1);
		player.moveDown();
		player.moveDown();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 3);
		player.moveDown();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 3);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 5);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 6);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 7);
		assertEquals(player.getY(), 3);
		player.moveRight();
		assertEquals(player.getX(), 7);
		assertEquals(player.getY(), 3);
		player.moveUp();
		assertEquals(player.getX(), 7);
		assertEquals(player.getY(), 3);
		player.moveDown();
		assertEquals(player.getX(), 7);
		assertEquals(player.getY(), 3);
		player.moveLeft();
		player.moveLeft();
		player.moveLeft();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 3);
		player.moveUp();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 2);
		player.moveUp();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 1);
		player.moveUp();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 0);
		player.moveUp();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 0);
		player.moveLeft();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 0);
		player.moveRight();
		assertEquals(player.getX(), 4);
		assertEquals(player.getY(), 0);
	}

}
