package testdungeon;

import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Treasure;
import unsw.dungeon.model.Wall;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPickTreasure {
	private Dungeon dungeon;
	private Player player;
	@Test
	void test() {
		/*
		 * test the player can pickup treasure and the treasure is wiped out from
		 * the entity and treasure list
		 * #### ###
		 * #p     #
		 * #      #
		 * # T    T 
		 * ########
		 */
		dungeon = new Dungeon(8, 5);
		player = new Player(dungeon, 1, 1);
		int i, j;
		for (i = 0 ; i < 8; i++) {
			for (j = 0 ; j < 5; j++) {
				if (i == 0 || j == 0 || i == 7 || j == 4) {
					if ((i == 7 && j == 3) || (i == 4 && j == 0)) {
						continue;
					}
					Wall wall = new Wall(i, j);
					dungeon.addEntity(wall);
					dungeon.addWall(wall);
				}
			}
		}
		
		Wall wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		Treasure t1 = new Treasure(2, 3);
		Treasure t2 = new Treasure(7, 3);
		dungeon.addEntity(t1);
		dungeon.addTreature(t1);
		dungeon.addEntity(t2);
		dungeon.addTreature(t2);
		// check the treasures are added
		assertEquals(dungeon.getTreasure().size(), 2);
		player.moveDown();
		player.moveDown();
		player.moveRight();
		assertEquals(player.getX(), 2);
		assertEquals(player.getY(), 3);
		assertEquals(t1.getshouldDie(), false);
		player.pickup();
		assertEquals(t1.getshouldDie(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getTreasure().size(), 1);
		player.moveRight();
		player.moveRight();
		player.moveRight();
		player.moveRight();
		player.moveRight();
		assertEquals(player.getX(), 7);
		assertEquals(player.getY(), 3);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getTreasure().size(), 1);
		player.pickup();
		dungeon.updateEntityStates();
		assertEquals(dungeon.getTreasure().size(), 0);
		assertEquals(t1.getshouldDie(), true);
		assertEquals(t2.getshouldDie(), true);
	}

}
