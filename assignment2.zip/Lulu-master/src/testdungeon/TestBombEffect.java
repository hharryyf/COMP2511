package testdungeon;


import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Potion;
import unsw.dungeon.model.Wall;
import unsw.dungeon.model.UnlitBomb;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBombEffect {

	
	/*
	* this unit test would check whether the bomb can effectively kill
	* all the enemies, player, boulders around it or at the point
	* 1. player with potion
	* 2. player without potion
	* 
	*/
	
	@Test
	void testWithPotion() {
		/*
		 * 
		 *  #D#
		 *  IBE
		 *  #E#
		 * 
		 */
		Dungeon dungeon = new Dungeon(3, 3);
		Player player = new Player(dungeon, 0, 1);
		Enemy e1 = new Enemy(dungeon, 1, 2);
		Enemy e2 = new Enemy(dungeon, 2, 1);
		dungeon.addEntity(e1);
		dungeon.addEntity(e2);
		dungeon.addEnemy(e1);
		dungeon.addEnemy(e2);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Potion potion = new Potion(0, 1);
		dungeon.addPotion(potion);
		dungeon.addEntity(potion);
		Boulder boulder = new Boulder(1, 0);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		Wall wall = new Wall(0, 0);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(2, 0);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(0, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		Bomb bomb = new UnlitBomb(dungeon, 1, 1);
		dungeon.addEntity(bomb);
		dungeon.addBomb(bomb);
		player.pickup();
		player.moveRight();
		player.pickup();
		assertEquals(player.hasBomb(), true);
		dungeon.updateGoal();
		player.putBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		// the player is not dead if it has a potion
		assertEquals(player.getshouldDie(), false);
		assertEquals(dungeon.getEnemy().size(), 2);
		assertEquals(dungeon.finishEnemy(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getEnemy().size(), 0);
		assertEquals(dungeon.getBoulder().size(), 0);
		assertEquals(boulder.getshouldDie(), true);
	}
	
	@Test
	void testWithoutPotion() {
		/*
		 * 
		 *  #D#
		 *  PBE
		 *  #E#
		 * 
		 */
		Dungeon dungeon = new Dungeon(3, 3);
		Player player = new Player(dungeon, 0, 1);
		Enemy e1 = new Enemy(dungeon, 1, 2);
		Enemy e2 = new Enemy(dungeon, 2, 1);
		dungeon.addEntity(e1);
		dungeon.addEntity(e2);
		dungeon.addEnemy(e1);
		dungeon.addEnemy(e2);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		Boulder boulder = new Boulder(1, 0);
		dungeon.addBoulder(boulder);
		dungeon.addEntity(boulder);
		Wall wall = new Wall(0, 0);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(2, 0);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(0, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		wall = new Wall(2, 2);
		dungeon.addEntity(wall);
		dungeon.addWall(wall);
		Bomb bomb = new UnlitBomb(dungeon, 1, 1);
		dungeon.addEntity(bomb);
		dungeon.addBomb(bomb);
		player.moveRight();
		player.pickup();
		assertEquals(player.hasBomb(), true);
		dungeon.updateGoal();
		player.putBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.reduceBomb();
		dungeon.updateGoal();
		
		assertEquals(player.getshouldDie(), true);
		assertEquals(dungeon.getEnemy().size(), 2);
		assertEquals(dungeon.finishEnemy(), true);
		dungeon.updateEntityStates();
		assertEquals(dungeon.getEnemy().size(), 0);
		assertEquals(dungeon.getBoulder().size(), 0);
		assertEquals(boulder.getshouldDie(), true);
	}
}
