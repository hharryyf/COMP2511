package testdungeon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Potion;
import unsw.dungeon.model.WildBeast;

class TestBeast {

	@Test
	void testMove() {
		Dungeon dungeon = new Dungeon(3,3);
		Player player = new Player(dungeon, 0, 0);
		dungeon.setPlayer(player);
		WildBeast beast = new WildBeast(dungeon, 2, 2);
		dungeon.addEntity(beast);
		dungeon.addWildBeast(beast);
		for(int i = 0 ; i < 1000; i++) {
			dungeon.enemyMove();
			if (beast.getX() >= dungeon.getWidth() || beast.getX() < 0 || beast.getY() >= dungeon.getHeight() || beast.getY() < 0) {
				fail("Invalid move");
			}
		}
		assertEquals(player.getshouldDie(), true);
	}
	
	@Test
	void testInteraction() {
		Dungeon dungeon = new Dungeon(3,3);
		Player player = new Player(dungeon, 0, 0);
		dungeon.setPlayer(player);
		WildBeast beast = new WildBeast(dungeon, 2, 2);
		dungeon.addEntity(beast);
		dungeon.addWildBeast(beast);
		player.moveRight();
		player.moveRight();
		player.moveDown();
		player.moveDown();
		assertEquals(player.getshouldDie(), true);
	}
	
	@Test
	void testProtect() {
		Dungeon dungeon = new Dungeon(3,3);
		Player player = new Player(dungeon, 0, 0);
		dungeon.setPlayer(player);
		WildBeast beast = new WildBeast(dungeon, 2, 2);
		dungeon.addEntity(beast);
		dungeon.addWildBeast(beast);
		Potion potion = new Potion(1,1);
		dungeon.addEntity(potion);
		dungeon.addPotion(potion);
		player.moveRight();
		player.moveDown();
		player.pickup();
		assertEquals(player.hasPotion(), true);
		player.moveRight();
		player.moveDown();
		for(int i = 0 ; i < 1000; i++) {
			dungeon.enemyMove();
			if (beast.getX() >= dungeon.getWidth() || beast.getX() < 0 || beast.getY() >= dungeon.getHeight() || beast.getY() < 0) {
				fail("Invalid move");
			}
		}
		assertEquals(player.getshouldDie(), false);
	}
}
