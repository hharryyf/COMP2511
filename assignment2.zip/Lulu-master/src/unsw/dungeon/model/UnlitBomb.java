package unsw.dungeon.model;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class UnlitBomb extends Bomb {

	private Player owner=null;
	public UnlitBomb(Dungeon dungeon, int x, int y) {
		super(dungeon, x, y);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void lightUp() {
		int x=this.owner.getX();
		int y=this.owner.getY();
		
		// this.dungeon.addActiveBomb(new ActiveBomb(this.dungeon,x,y));
		ActiveBomb acb = new ActiveBomb(this.dungeon,x,y);
		if (this.getView() != null) {
			Image bombImage = new Image("/bomb_lit_1.png");
			ImageView view = new ImageView(bombImage);
			dungeon.getObserver().addView(view, x, y);
			acb.setView(view);
		}
		this.dungeon.addActiveBomb(acb);
		this.owner.dropBomb(this);
	}

	@Override
	public void setOwner(Player n) {
		this.owner=n;
		this.setShouldDie();
		
	}
}
