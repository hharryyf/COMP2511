package unsw.dungeon.model;

public interface Goal {
	/**
	 * check whether the current goal state has been finished
	 * @return boolean
	 */
	public boolean hasfinish();
	/**
	 * show the goal and all its subgoal as a string
	 * @param depth
	 * @return a String
	 */
	public String display(int depth);
}
