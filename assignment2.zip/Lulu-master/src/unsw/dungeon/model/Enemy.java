package unsw.dungeon.model;

public class Enemy extends Entity {
	private Dungeon dungeon;
	private EnemyState moveState;
	private EnemyIQ moveLevel;
	private int pause = 0;
	public Enemy(Dungeon dungeon, int x, int y) {
		super(x, y);
		this.dungeon = dungeon;
		// TODO Auto-generated constructor stub
		this.moveState = new Moving(this); 
		this.moveLevel = new IdiotEnemy(dungeon, this);
	}
	
	public Enemy(Dungeon dungeon, int x, int y, int IQ) {
		super(x, y);
		this.dungeon = dungeon;
		// TODO Auto-generated constructor stub
		this.moveState = new Moving(this); 
		if (IQ < 10) {
			this.moveLevel = new SmartEnemy(dungeon, this);
		} else {
			// System.out.println(x + " " + y);
			this.moveLevel = new UnpredictableEnemy(dungeon, this);
		}
	}
	
	/**
	 * enemy move
	 */
	public void move() {
		moveState.move();
	}
	
	/**
	 * set the move state
	 */
	
	public void setMove() {
		this.pause = 0;
		this.moveState = new Moving(this); 
	}
	
	/**
	 * set the enemy to stop, and band its move for 1 round
	 */
	
	public void setStop() {
		this.moveState = new EnemyStop(this);
		this.setPause(1);
	}
	
	/**
	 * let the enemy to pause 
	 * @param t refers to the rounds
	 */
	
	public void setPause(int t) {
		this.pause = t;
	}
	
	/**
	 * get the pause seconds
	 * @return
	 */
	
	public int getPause() {
		return this.pause;
	}
	
	/**
	 * get the enemy moving level
	 * @return the moving level
	 */
	
	public EnemyIQ getEnemyIQ() {
		return this.moveLevel;
	}
	
	/**
	 * 
	 * @return the dungeon that the enemy points to
	 */
	
	public Dungeon getDungeon() {
		return this.dungeon;
	}
	
	/**
	 * check whether the enemy is moveable
	 * @return true/false
	 */
	
	public boolean isMovable() {
		return (this.moveState instanceof Moving);
	}
}
