package unsw.dungeon.model;

import java.util.List;

public class ActiveBomb extends Entity {
	private int timer=5;
	private Dungeon dungeon;
	public ActiveBomb(Dungeon dungeon, int x, int y) {
		super(x, y);
		this.dungeon = dungeon;
	}
	
	public void reduceTimer() {
		timer--;
		if(timer==0) {
			int[] dx = {0,1,-1,0,0};
			int[] dy = {0,0,0,-1,1};
			
			for (int i = 0 ; i < 5; i++) {
				if (dungeon.getPlayer() != null) {
					if (dungeon.getPlayer().getX() == getX() + dx[i] 
							&& dungeon.getPlayer().getY() == getY() + dy[i] && !dungeon.getPlayer().hasPotion()) {
						dungeon.getPlayer().setShouldDie();
					}
				}
				Boulder b =this.dungeon.getBoulder(getX() + dx[i], getY() + dy[i]);
				List<Enemy> eS= this.dungeon.getEnemy(getX() + dx[i], getY() + dy[i]);
				
				for(Enemy tmp: eS) {
					System.out.println("bomb at " + this.getX() + " " + this.getY() + "the enemy died at " + tmp.getX() + " " + tmp.getY());
					tmp.setShouldDie();
				}
				
				if(b!=null) b.setShouldDie();
			}
			this.setShouldDie();
			
			System.out.println("Exploation!!" + " " + getX() + " " + getY());
		}
		
	}
	
	public int getTimer() {
		return this.timer;
	}
}
