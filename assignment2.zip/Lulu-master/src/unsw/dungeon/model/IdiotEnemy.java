package unsw.dungeon.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IdiotEnemy implements EnemyIQ {

	private Dungeon dungeon;
	private Enemy enemy;
	public IdiotEnemy(Dungeon dungeon, Enemy e) {
		this.dungeon = dungeon;
		this.enemy = e;
	}
	@Override
	public int[] nextboard() {
		List<int[]> candidate = new ArrayList<int[]>();
		int currx = enemy.getX(), curry = enemy.getY();
		int[] dx = {0,0,1,-1};
		int[] dy = {1,-1,0, 0};
		for (int i = 0 ; i < 4; i++) {
			int[] t = new int[2];
			t[0] = dx[i]+currx;
			t[1] = dy[i]+curry;
			candidate.add(t);
		}
		
		// System.out.println(dungeon.getPlayer().hasPotion());
		Collections.sort(candidate, (int[] a, int[] b)-> {
			// System.out.println("hello world");
			
			int dist1 = Math.abs(a[0] - dungeon.getPlayer().getX()) + Math.abs(a[1] - dungeon.getPlayer().getY());
			int dist2 = Math.abs(b[0] - dungeon.getPlayer().getX()) + Math.abs(b[1] - dungeon.getPlayer().getY());
			int factor = dungeon.getPlayer().hasPotion() ? 1 : -1;
			Integer it1 = new Integer(dist1);
			Integer it2 = new Integer(dist2);
			return it1.compareTo(it2) * factor * (-1);
		});
		
		for (int[] next: candidate) {
			if (validPos(next[0], next[1])) {
				return next;
			}
		}
		
		int[] next = {enemy.getX(),enemy.getY()};
		return next;
	}
	
	private boolean validPos(int x, int y) {
		if (!dungeon.withinBoundary(x, y)) return false;
		if (!dungeon.hasWall(x, y) && dungeon.getClosedDoor(x, y) == null && dungeon.getBoulder(x, y) == null) {
			return true;
		}
		return false;
	}

}
