package unsw.dungeon.model;

import java.util.List;

/*
 * in the EnemyRound the judge will fulfill the following things
 * 1. check the result:
 *    basically: enemy and user appears in the same cell, see who should die
 *    a tricker one: check who will be destroyed by the bomb
 * 
 *    
 * 2. reset the status of the board:
 *    2-1) trap the isMoveable enemy that presents next to the triggered switch     
 * 
 * */


public class EnemyRound implements JudgeState {
	private Judge judge;
	public EnemyRound(Judge judge) {
		this.judge = judge;
	}

	@Override
	public String gameResult() {
		List<Enemy> enemy = judge.getAllEnemy();
		Player player = judge.getPlayer();
		judge.getDungeon().reduceBomb();
		if (player.getshouldDie()) return new String("User Lost!");
		for (Enemy e : enemy) {
			if (enemyKillPlayer(e, player)) {
				player.setShouldDie();
				return new String("User Lost!");
			} else if (playerKillEnemy(e, player)) {
				e.setShouldDie();
			}
		}
		
		Dungeon dungeon = judge.getDungeon();
		dungeon.updateGoal();
		if (player.completeGoal()) {
			return new String("User Win!");
		}
		return new String("Draw!");
	}
	
	@Override
	public void changeLocation() {
		// in the changeLocation method after the enemy move, we just simply
		// freeze all the moveable enemy that is adjacent to the triggered switch
		Dungeon dungeon = judge.getDungeon();
		dungeon.updateEntityStates();
		List<Enemy> enemy = dungeon.getEnemy();
		int[] dx = {0, 0, 1, -1, 0};
		int[] dy = {1, -1, 0, 0, 0};
		for (Enemy e : enemy) {
			if (e.isMovable()) {
				for (int i = 0 ; i < 5; i++) {
					int tx = dx[i] + e.getX();
					int ty = dy[i] + e.getY();
					Switch sw = dungeon.getSwitch(tx, ty);
					if (sw != null && sw.isTriggers()) {
						e.setStop();
						System.out.println(e.getX() + " " + e.getY() + " stop!");
					}
				}
			}
		}
		
		changeState();
	}
	
	/**
	 * check whether e could kill p
	 * @param  Enemy e
	 * @param  Player p
	 * @return true false
	 */
	
	public boolean enemyKillPlayer(Enemy e, Player p) {
		// the player has no potion
		if (p.hasPotion() == false && e.getX() == p.getX() && e.getY() == p.getY()) {
			return true;
		}
		return false;
	}
	
	/**
	 * check whether p could kill e
	 * @param  Enemy e
	 * @param  Player p
	 * @return true false
	 */
	
	public boolean playerKillEnemy(Enemy e, Player p) {
		if (p.hasPotion() == true && e.getX() == p.getX() && e.getY() == p.getY()) {
			return true;
		}
		return false;
	}
	
	@Override
	public void changeState() {
		judge.setState(new UserRound(judge));
	}
}
