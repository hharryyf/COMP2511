package unsw.dungeon.model;

public class Treasure extends Pickupable {
	private boolean ispicked;
	public Treasure(int x, int y) {
		super(x, y);
		this.ispicked = false;
		// TODO Auto-generated constructor stub
	}
	

	
	/**
	 * 
	 * @return whether the treasure is picked up, for unit test only!!
	 */
	
	public boolean haspicked() {
		return this.ispicked;
	}
}
