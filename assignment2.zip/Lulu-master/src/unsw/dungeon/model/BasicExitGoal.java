package unsw.dungeon.model;

public class BasicExitGoal implements Goal {
	private Dungeon dungeon;
	public BasicExitGoal(Dungeon dungeon) {
		this.dungeon = dungeon;
	}

	
	
	@Override
	public boolean hasfinish() {
		return dungeon.finishExit();
	}
	
	@Override
	public String display(int depth) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0  ; i < depth; i++) {
			sb.append("\t");
		}
		return sb.append("[goal: exit " + " complete " + this.hasfinish() + "]\n").toString();
	}

}
