package unsw.dungeon.model;
/**
 * 
 * @author joeyzhuangyi
 *	the pickable items
 */
public abstract class Pickupable extends Entity {
	private Player owner;
	public Pickupable(int x, int y) {
		
		super(x, y);
		this.owner=null;
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 
	 * @return owner of the current pickupable entity
	 */
	
	public Player getOwner() {
		return owner;
	}
	
	/**
	 * set the owner of the current item to a player
	 * @param Player owner
	 */
	public void setOwner(Player owner) {
		this.setShouldDie();
		this.owner = owner;
	}

	
}
