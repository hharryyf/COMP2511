package unsw.dungeon.model;

public class Sword extends Pickupable {
	private int remainhits;
	
	public Sword(int x, int y) {
		super(x, y);
		
		this.setRemainhits(5);
		// TODO Auto-generated constructor stub
	}
	/**
	 * reduce the hit point of the sword
	 */
	public void reduceHits() {
		this.remainhits--;
		if(this.remainhits==0) {
			super.getOwner().deleteSword();
			// this.owner=null;
		}
	}
	

	/**
	 * get the remaining hits of the sword
	 * @return sword
	 */

	public int getRemainhits() {
		return remainhits;
	}
	
	/**
	 * set the remaining hits of the sword
	 * @param remainhits
	 */
	
	public void setRemainhits(int remainhits) {
		this.remainhits = remainhits;/*
		if (this.remainhits == 0) {
			this.setShouldDie();
		}*/
	}
	

}
