package unsw.dungeon.model;

public interface JudgeState {
	/**
	 * return the result of the current gameboard
	 * @return String Draw/user win/user lose
	 */
	public String gameResult();
	/**
	 * change the location of the entities on the board
	 */
	public void changeLocation();
	/**
	 * change the judge state of the judge: this is a state pattern
	 */
	public void changeState();
}
