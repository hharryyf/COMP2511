/**
 *
 */
package unsw.dungeon.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javafx.scene.image.ImageView;
import unsw.dungeon.controller.DungeonController;


/**
 * A dungeon in the interactive dungeon player.
 *
 * A dungeon can contain many entities, each occupy a square. More than one
 * entity can occupy the same square.
 *
 * @author Robert Clifton-Everest
 *
 */
public class Dungeon {
    private int width, height;
    private List<Entity> entities;
    private Player player;
    private List<Enemy> enemies;
    
    private DungeonController observer;
    // static entities
    private Map<String, Wall> walls;
    private Map<String, Switch> switches;
    private Map<String, Doors> doors;
    private List<Boulder> boulders;
    // bomb is quite special, it can be collect and drop
    
    //
    private List<Sword> swords;
    private List<Treasure> treasures;
    private List<Bomb> unlitbombs;
    private List<ActiveBomb> activebombs;
    private List<Key> keys;
    private List<Potion> potions;
    private boolean finishexit;
    private boolean finishenemy;
    private boolean finishtreasure;
    private boolean finishboulder;
    
    private Map<String, Exit> exits;
    
    private List<WildBeast> beasts;
    public Dungeon(int width, int height) {
        this.width = width;
        this.height = height;
        this.entities = new LinkedList<>();
        this.player = null;
        this.unlitbombs = new LinkedList<>();
        this.activebombs = new LinkedList<>();
        this.boulders = new LinkedList<>();
        this.doors = new HashMap<>();
        this.potions = new LinkedList<>();
        this.keys = new LinkedList<>();
        this.switches = new HashMap<>();
        this.walls = new HashMap<>();
        this.swords = new LinkedList<>();
        this.enemies = new LinkedList<>();
        this.treasures = new LinkedList<>();
        this.exits = new HashMap<>();
        this.finishenemy = true;
        this.finishenemy = true;
        this.finishtreasure = true;
        this.finishboulder = true;
        this.beasts = new LinkedList<>();
    }
    
    /**
     * 
     * @return width of the dungeon
     */
    public int getWidth() {
        return width;
    }
    
    /**
     * 
     * @return height of the dungeon
     */
    
    public int getHeight() {
        return height;
    }
    
    /**
     * 
     * @return the player
     */
    public Player getPlayer() {
        return player;
    }
    
    /**
     * 
     * @param set the player tp be Player player
     */
    public void setPlayer(Player player) {
        this.player = player;
    }
    
    /**
     * add entity to the entity list
     * @param entity
     */
    public void addEntity(Entity entity) {
        entities.add(entity);
    }
    
    /**
     * add enemy to the enemy list
     * @param enemy
     */
    
    public void addEnemy(Enemy enemy) {
    	this.enemies.add(enemy);
    }
    
    /**
     * add bomb to the bomb list
     * @param bomb
     */
    public void addBomb(Bomb bomb) {
    	this.unlitbombs.add(bomb);
    }
    
    /**
     * add active bomb to the active bomb list
     * @param bomb
     */
    
    public void addActiveBomb(ActiveBomb bomb) {
    	this.entities.add(bomb);
        this.activebombs.add(bomb);
        // sqare.getChildren().add(bombv);
    }
    
    /**
     * add wall to the wall hashmap
     * @param wall
     */
    
    public void addWall(Wall wall) {
    	this.walls.put(location(wall.getX(), wall.getY()), wall);
    }
    
    /**
     * add key to the key list
     * @param key
     */
    
    public void addKey(Key key) {
    	this.keys.add(key);
    }
    
    /**
     * add potion to the potion list
     * @param potion
     */
    
    public void addPotion(Potion potion) {
    	this.potions.add(potion);
    }
    
    /**
     * add boulder to the boulder list
     * @param boulder
     */
    
    public void addBoulder(Boulder boulder) {
    	this.boulders.add(boulder);
    }
    
    /**
     * add sword to the sword list
     * @param sword
     */
    
    public void addSword(Sword sword) {
    	this.swords.add(sword);
    }
    
    /**
     * add switch to the switch hashmap
     * @param switches
     */
    
    public void addSwich(Switch switches) {
    	this.switches.put(location(switches.getX(), switches.getY()), switches);
    }
    
    /**
     * add door to the door hashmap
     * @param door
     */
    
    public void addDoor(Doors door) {
    	this.doors.put(location(door.getX(), door.getY()), door);
    }
    
    /**
     * a static method, basically it just try to return the (x, y) as a string
     * @param x
     * @param y
     * @return string representation of the coordinate
     */
    
    public static String location(int x, int y) {
    	return String.valueOf(x) + "," + String.valueOf(y);
    }
    
    /**
     * 
     * @return all enemy as a list
     */
    
    public List<Enemy> getEnemy() {
    	return this.enemies;
    }
    
    /**
     * 
     * @param x
     * @param y
     * @return all enemy at the location (x, y)
     */
    
    public List<Enemy> getEnemy(int x,int y) {
    	List<Enemy> ret = new LinkedList<>();
    	for(Enemy tmp: this.enemies) {
    		if(tmp.getX()==x &&tmp.getY()==y)ret.add(tmp);
    	}
    	return ret;
    }
    
    /**
     * 
     * @return all sword as a list
     */
    
    public List<Sword> getSword() {
    	return this.swords;
    }
    
    /**
     * 
     * @return all potion as a list, for debugging and unit test purpose
     */
    
    public List<Potion> getPotion() {
    	return this.potions;
    }
    
    /**
     * 
     * @return all key as a list , for debugging and unit test purpose
     */
    public List<Key> getKey() {
    	return this.keys;
    }
    
    /**
     * 
     * @return all door as a list, , for debugging and unit test purpose
     */
    
    public Map<String, Doors> getDoor() {
    	return this.doors;
    }
    
    /**
     * 
     * @return all boulders as a list, for debugging and unit test purpose
     */
    
    public List<Boulder> getBoulder() {
    	return this.boulders;
    }
    
    /**
     * 
     * @return all bombs as a list, for debugging and unit test purpose
     */
    public List<Bomb> getBombs() {
    	return this.unlitbombs;
    }
    
    /**
     * 
     * @return all active bomb as a list
     */
    
    public List<ActiveBomb> getActiveBombs() {
    	return this.activebombs;
    }
    
    public Map<String, Switch> getSwitch() {
    	return this.switches;
    }
    
    
    /**
     * wipe out all the dead entities
     * pass on the changes into the controlller
     */
    
    public void updateEntityStates() {
    	List<ImageView> deletes = new ArrayList<ImageView>();
    	Iterator<Entity> iter = entities.iterator();
    	while (iter.hasNext()) {
    		Entity current = iter.next();

    		if (current == null) {
    			System.out.println("error !");
    			continue;
    		}
    		if (current.getshouldDie()) {
    			// System.out.println("false");
    			deletes.add(current.getView());
    			iter.remove();
    		}
    	}
    	
    	deleteWasteSword();
    	deleteDeadBoulder();
    	deleteDeadBomb();
    	deleteDeadEnemy();
    	deleteDeadPotion();
    	deleteDeadTreasure();
    	deleteDeadKey();
    	
    	
    	if (this.observer != null) {
    		this.observer.updateView(deletes,this.player.getInventoryState());
    	}
    }
    
    private void deleteDeadTreasure() {
    	Iterator<Treasure> iter = treasures.iterator();
    	while (iter.hasNext()) {
    		Treasure current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    private void deleteDeadKey() {
    	Iterator<Key> iter = keys.iterator();
    	while (iter.hasNext()) {
    		Key current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    /**
     * add a wild beast
     * @param wb
     */
    
    public void addWildBeast(WildBeast wb) {
    	this.beasts.add(wb);
    }
    
    /**
     * return all the wild beasts in x, y
     * @param x
     * @param y
     * @return List of wild beasts
     */
    
    public List<WildBeast> getWildBeast(int x, int y) {
    	List<WildBeast> ret = new LinkedList<>();
    	for (WildBeast bt : this.beasts) {
    		if (bt.getX() == x && bt.getY() == y) {
    			ret.add(bt);
    		}
    	}
    	
    	return ret;
    }
    
    private void deleteDeadPotion() {
    	Iterator<Potion> iter = potions.iterator();
    	while (iter.hasNext()) {
    		Potion current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    
    /**
     * 
     * @param x
     * @param y
     * @return the boulder at x, y with null as a default option
     */
    public Boulder getBoulder(int x, int y) {
    	for (Boulder b : this.boulders) {
    		if (b.getX() == x && b.getY() == y) return b;
    	}
    	return null;
    }
    /**
     * return the closed door at position x, y
     * 
     * @param x
     * @param y
     * @return Doors object or null if the foor is opened or no door at that spot
     */
    public Doors getClosedDoor(int x, int y) {
    	Doors door =  this.doors.getOrDefault(location(x, y), null);
    	if (door == null || door.isOpen()) return null;
    	return door;
    }
    /**
     * check x, y has a wall or not
     * @param x
     * @param y
     * @return true for has a wall/ false otherwise
     */
    public boolean hasWall(int x, int y) {
    	Wall wall = this.walls.getOrDefault(location(x, y), null);
    	if (wall == null || wall.getX() != x || wall.getY() != y) return false;
    	return true;
    }
    
    /**
     * 
     * @param x
     * @param y
     * @return all the bombs located in the cell x, y
     */
    
    public List<Bomb> getBomb(int x, int y) {
    	List<Bomb> ret = new LinkedList<>();
    	for (Bomb b : this.unlitbombs) {
    		if (b.getX() == x && b.getY() == y) {
    			ret.add(b);
    		}
    	}
    	return ret;
    }
    
    /**
     * 
     * @param x
     * @param y
     * @return the switch located at x, y/ null as default
     */
    public Switch getSwitch(int x, int y) {
    	return this.switches.getOrDefault(location(x, y), null);
    }
    
    private void deleteDeadEnemy() {
    	Iterator<Enemy> iter = enemies.iterator();
    	while (iter.hasNext()) {
    		Enemy current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    private void deleteDeadBomb() {
    	
    	Iterator<Bomb> iter = unlitbombs.iterator();
    	while (iter.hasNext()) {
    		Bomb current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    	Iterator<ActiveBomb> iter2 = activebombs.iterator();
    	while (iter2.hasNext()) {
    		ActiveBomb current = iter2.next();
    		if (current.getshouldDie()) {
    			iter2.remove();
    		}
    	}
    }
    
    private void deleteDeadBoulder() {
    	Iterator<Boulder> iter = boulders.iterator();
    	while (iter.hasNext()) {
    		Boulder current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    private void deleteWasteSword() {
    	Iterator<Sword> iter = swords.iterator();
    	while (iter.hasNext()) {
    		Sword current = iter.next();
    		if (current.getshouldDie()) {
    			iter.remove();
    		}
    	}
    }
    
    /**
     * get the potion at position x, y
     * @param x
     * @param y
     * @return potion/null
     */
    
    public Potion getPotion(int x,int y) {
    	
    	for(Potion tmp:this.potions) {
    		if(tmp.getX()==x && tmp.getY()==y)return tmp;
    	}
    	return null;
    }
    
    /**
     * get the sword at position x, y
     * @param x
     * @param y
     * @return sword/null
     */
    public Sword getSword(int x,int y) {
    	
    	for(Sword tmp:this.swords) {
    		if(tmp.getX()==x && tmp.getY()==y)return tmp;
    	}
    	return null;
    }
    
    
    /**
     * the key at position x, y
     * @param x
     * @param y
     * @return key/null
     */
    public Key getKey(int x,int y) {
    	
    	for(Key tmp:this.keys) {
    		if(tmp.getX()==x && tmp.getY()==y)return tmp;
    	}
    	return null;
    }
    
    /**
     * to string method, basically trys to debug the dungeon
     */
    public String toString() {
    	return "this dungeon has " + entities.size() + " entities " + " and " + enemies.size() + " enemies\n";
    }
    
    /**
     * add treasure to the list
     * @param treasure
     */
    
    public void addTreature(Treasure t) {
    	this.treasures.add(t);
    }
    
    /**
     * add exit to the map
     * @param exit
     */
    
    public void addExit(Exit e) {
    	this.exits.put(location(e.getX(), e.getY()), e);
    }
    
    
    /**
     * get exit at position x, y
     * @param x
     * @param y
     * @return exit/null
     */
    public Exit getExit(int x, int y) {
    	return this.exits.getOrDefault(location(x, y), null);
    }
    
    /**
     * get treasure at position x, y
     * @param x
     * @param y
     * @return treasure/null
     */
    
    public List<Treasure> getTreasure(int x, int y) {
    	List<Treasure> ans = new LinkedList<>();
    	for (Treasure t : this.treasures) {
    		if (t.getX() == x && t.getY() == y) {
    			ans.add(t);
    		}
    	}
    	return ans;
    }
    
    /**
     * basically this is a debug and unit test function/don't call it for other purpose!
     * @return
     */
    
    public List<Treasure> getTreasure() {
    	return this.treasures;
    }
    
    /**
     * update the goal status of th 4 basic goals
     */
    
    public void updateGoal() {
    	this.finishenemy = true;
    	for (Enemy e : this.enemies) {
    		if (!e.getshouldDie()) {
    			finishenemy = false;
    		}
    	}
    	this.finishtreasure = true;
    	for (Treasure e : this.treasures) {
    		if (!e.getshouldDie()) {
    			finishtreasure = false;
    		}
    	}
    	this.finishexit = (this.player != null && this.getExit(player.getX(), player.getY()) != null);
    	this.finishboulder = true;
    	Iterator<Map.Entry<String, Switch>> iter = this.switches.entrySet().iterator();
    	while (iter.hasNext()) {
    		Map.Entry<String, Switch> entry = iter.next();
    		Boulder boulder = this.getBoulder(entry.getValue().getX(), entry.getValue().getY());
    		if (boulder == null || boulder.getshouldDie()) {
    			entry.getValue().setTriggers(false);
    			this.finishboulder = false;		
    		} else {
    			entry.getValue().setTriggers(true);
    		}
    	}
    }
    
    /**
     * helper function for the goal
     * @return whether the enemy goal is done
     */
    public boolean finishEnemy() {
    	return this.finishenemy;
    }
    
    /**
     * helper function for the goal
     * @return whether the treasure is done
     */
    
    public boolean finishTreasure() {
    	return this.finishtreasure;
    }
    
    /**
     * helper function for the exit
     * @return whether the exit is done
     */
    
    public boolean finishExit() {
    	return this.finishexit;
    }
    
    /**
     * helper function for the boulder
     * @return whether the boulder is done
     */
    
    public boolean finishBoulder() {
    	return this.finishboulder;
    }
    /**
     * return if a cell has nothing but probably a switch, a opened door
     * @param x
     * @param y
     * @return
     */
    public boolean cellEmpty(int x, int y) {
    	// invalid place automatically return false
    	if (!withinBoundary(x, y)) return false;

    	for (Entity e : this.entities) {
    		if (e.getX() == x && e.getY() == y && !e.getshouldDie()) {
    			if (!(e instanceof Doors) && !(e instanceof Switch)) {
    				return false;
    			}
    			
    			if (e instanceof Doors) {
    				if (((Doors) e).isOpen() == false) {
    					return false;
    				}
    			}
    		}
    	}
    	return true;
    }
    
    /**
     * return if (x, y) is within the boundary of the dungeon
     * @param x
     * @param y
     * @return
     */
    
    public boolean withinBoundary(int x, int y) {
    	if (x < 0 || x >= this.getWidth() || y < 0 || y >= this.getHeight()) return false;
    	return true;
    }
    /**
     * reduce the timer of all the bombs
     */
    public void reduceBomb() {
		List<ActiveBomb> bombs = this.getActiveBombs();
		for (ActiveBomb b : bombs) {
			b.reduceTimer();
			if (this.observer != null) {
				ActiveBomb bb = (ActiveBomb) b;
				observer.updateBombView(b.getView(), bb.getTimer());
			}
		}
	
    }
    /**
     * let all the alive enemy move, and let all the wild beasts move
     */
    public void enemyMove() {
    	for (Enemy e : this.enemies) {
    		if (!e.getshouldDie()) {
    			e.move();
    		}
    	}
    	
    	for (WildBeast b : this.beasts) {
    		b.move();
    	}
    }
    
    

	public DungeonController getObserver() {
		return observer;
	}

	public void setObserver(DungeonController observer) {
		this.observer = observer;
	}
	
	public List<Entity> getEntity() {
		return this.entities;
	}
    
 }
