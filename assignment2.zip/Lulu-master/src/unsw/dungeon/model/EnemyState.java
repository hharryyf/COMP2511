package unsw.dungeon.model;

public interface EnemyState {
	/**
	 * move the enemy under the current moving state
	 */
	public void move();
}
