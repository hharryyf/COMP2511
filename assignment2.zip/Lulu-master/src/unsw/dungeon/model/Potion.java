package unsw.dungeon.model;

public class Potion extends Pickupable {
	

	private int remained;
	public Potion(int x, int y) {
		super(x, y);
		this.remained=5;
	}
	/**
	 * 
	 * @return the remaining round for the potion to work
	 */
	
	public int getRemained() {
		return remained;
	}


	/**
	 * reduce the effect of the potion
	 */
	
	public void reduceEffect() {
		this.remained--;
	}

}
