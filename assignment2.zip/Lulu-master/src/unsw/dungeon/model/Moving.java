package unsw.dungeon.model;

public class Moving implements EnemyState {

	private Enemy enemy;
	public Moving(Enemy enemy) {
		this.enemy = enemy;
	}

	
	@Override
	public void move() {
		int[] nextmove = enemy.getEnemyIQ().nextboard();
		enemy.x().set(nextmove[0]);
		enemy.y().set(nextmove[1]);
	}
}
