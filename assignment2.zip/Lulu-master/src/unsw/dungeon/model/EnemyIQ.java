package unsw.dungeon.model;

public interface EnemyIQ {
	/**
	 * nextboard the enemy would move under the current IQ level
	 * @return int[2] {nextx, nexty}
	 */
	public int[] nextboard();
}
