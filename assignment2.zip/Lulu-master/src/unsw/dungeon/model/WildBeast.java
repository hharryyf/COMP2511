package unsw.dungeon.model;

import java.util.Random;

public class WildBeast extends Entity {
	Dungeon dungeon;
	public WildBeast(Dungeon dungeon, int x, int y) {
		super(x, y);
		this.dungeon = dungeon;
	}
	
	/**
	 * what the wild beast is doing is to walk randomly in 8!!!
	 * directions, as long as there isn't a wall, boulder, closed door
	 */
	
	public void move() {
		Random r = new Random();
		int[] dx = {0,1,1,1,-1,-1,-1,0,0};
		int[] dy = {0,0,1,-1,1,-1,0,1,-1};
		int round = 1000;
		int[] next = {super.getX(), super.getY()};
		while (round > 0) {
			int index = r.nextInt(9);
			int tx = next[0] + dx[index];
			int ty = next[1] + dy[index];
			if (validPos(tx, ty)) {
				next[0] = tx;
				next[1] = ty;
				break;
			}
			round--;
		}
		
		this.x().set(next[0]);
		this.y().set(next[1]);
		
		killPlayer();
	}
	
	private void killPlayer() {
		Player player = dungeon.getPlayer();
		if (player != null) {
			if (getX() == player.getX() && getY() == player.getY() && !player.hasPotion()) {
				player.setShouldDie();
			}
		}
	}
	
	private boolean validPos(int x, int y) {
		if (!dungeon.withinBoundary(x, y)) return false;
		if (!dungeon.hasWall(x, y) && dungeon.getClosedDoor(x, y) == null && dungeon.getBoulder(x, y) == null) {
			return true;
		}
		return false;
	}
}
