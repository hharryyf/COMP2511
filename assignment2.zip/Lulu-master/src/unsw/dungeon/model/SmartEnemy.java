package unsw.dungeon.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;

public class SmartEnemy implements EnemyIQ {
	private Dungeon dungeon;
	private Enemy enemy;
	public SmartEnemy(Dungeon dungeon, Enemy enemy) {
		this.dungeon = dungeon;
		this.enemy = enemy;
	}

	@Override
	public int[] nextboard() {
		List<int[]> candidates = new ArrayList<>();
		int[] dx = {0, 0, 1, -1};
		int[] dy = {1, -1, 0, 0};
		int i, currx = enemy.getX(), curry = enemy.getY();
		for (i = 0 ; i < 4; i++) {
			int[] curr = new int[3];
			curr[0] = currx + dx[i];
			curr[1] = curry + dy[i];
			curr[2] = Astar(curr[0], curr[1]);
			// System.out.println(curr[0] + "," + curr[1] + " dist= " + curr[2]);
			candidates.add(curr);
		}
		
		int[] ans = new int[2];
		ans[0] = enemy.getX();
		ans[1] = enemy.getY();
		
		Collections.sort(candidates, (int[] a, int[] b)-> {
			Integer it1 = new Integer(a[2]);
			Integer it2 = new Integer(b[2]);
			int factor = dungeon.getPlayer().hasPotion() ? 1 : -1;
			return it1.compareTo(it2) * factor * (-1);
		});
		
		for (int[] arr : candidates) {
			if (validPos(arr[0], arr[1])) {
				ans[0] = arr[0];
				ans[1] = arr[1];
				break;
			}
		}
		return ans;
	}
	/**
	 * a private method using A* algorithm to find the shortest
	 * path from (startx, starty) to player without making any invalid move
	 * @return length
	 */
	private int Astar(int startx, int starty) {
		if (!validPos(startx, starty)) {
			return Integer.MAX_VALUE - 1;
		}
		HashSet<String> visited = new HashSet<String>();
		PriorityQueue<int[]> q = new PriorityQueue<int[]>((int[] a, int[] b)-> {
			Integer it1 = new Integer(a[3]);
			Integer it2 = new Integer(b[3]);
			return it1.compareTo(it2);
		});
		
		int[] curr = new int[4];
		int[] dx = {0, 0, 1, -1};
		int[] dy = {1, -1, 0, 0};
		
		curr[0] = startx;
		curr[1] = starty;
		curr[2] = 0;
		curr[3] = heuristic(startx, starty);
		q.add(curr);
		visited.add(Dungeon.location(curr[0], curr[1]));
		while (!q.isEmpty()) {
			curr = q.poll().clone();
			// System.out.println(curr[0] + " " + curr[1]);
			if (curr[0] == dungeon.getPlayer().getX() && curr[1] == dungeon.getPlayer().getY()) {
				return curr[2];
			}
			
			for (int i = 0 ; i < 4; i++) {
				int[] nextstate = new int[4];
				nextstate[0] = curr[0] + dx[i];
				nextstate[1] = curr[1] + dy[i];
				nextstate[2] = cost(curr[0], curr[1]) + curr[2];
				nextstate[3] = cost(curr[0], curr[1]) + curr[2] + heuristic(nextstate[0], nextstate[1]);
				if (validPos(nextstate[0], nextstate[1]) && !visited.contains(Dungeon.location(nextstate[0], nextstate[1]))) {
					visited.add(Dungeon.location(nextstate[0], nextstate[1]));
					q.add(nextstate);
				}
			}
		}
		return Integer.MAX_VALUE - 1;
	}
	
	private boolean validPos(int x, int y) {
		if (!dungeon.withinBoundary(x, y)) return false;
		if (!dungeon.hasWall(x, y) && dungeon.getClosedDoor(x, y) == null && dungeon.getBoulder(x, y) == null) {
			return true;
		}
		return false;
	}
	
	private int cost(int x, int y) {
		if (dungeon.getSwitch(x+1, y) == null || !dungeon.getSwitch(x+1, y).isTriggers()) return 1;
		if (dungeon.getSwitch(x-1, y) == null || !dungeon.getSwitch(x-1, y).isTriggers()) return 1;
		if (dungeon.getSwitch(x, y+1) == null || !dungeon.getSwitch(x, y+1).isTriggers()) return 1;
		if (dungeon.getSwitch(x, y-1) == null || !dungeon.getSwitch(x, y-1).isTriggers()) return 1;
		return 2;
	}
	
	/**
	 * the Mahattan distance heuristic
	 * @param x
	 * @param y
	 * @return the manhattan distance from current point to the player
	 */
	
	private int heuristic(int x, int y) {
		return Math.abs(x - dungeon.getPlayer().getX()) + Math.abs(y - dungeon.getPlayer().getY());
	}
}
