package unsw.dungeon.model;

import java.util.List;


public class UserRound implements JudgeState {
	private Judge judge;
	public UserRound(Judge judge) {
		this.judge = judge;
	}

	@Override
	public String gameResult() {
		Player player = judge.getPlayer();
		Dungeon dungeon = judge.getDungeon();
		
		// dungeon.reduceBomb();
		if (player.getshouldDie()) return new String("User Lost!");
		dungeon.updateGoal();
		player.reducePotion();
		if (player.completeGoal()) return new String("User Win!");
		return new String("Draw!");
	}

	@Override
	public void changeLocation() {
		Dungeon dungeon = judge.getDungeon();
		dungeon.updateEntityStates();
		List<Enemy> enemy = dungeon.getEnemy();
		int[] dx = {0, 0, 1, -1, 0};
		int[] dy = {1, -1, 0, 0, 0};
		for (Enemy e : enemy) {
			if (e.isMovable()) {
				for (int i = 0 ; i < 5; i++) {
					int tx = dx[i] + e.getX();
					int ty = dy[i] + e.getY();
					Switch sw = dungeon.getSwitch(tx, ty);
					if (sw != null && sw.isTriggers()) {
						e.setStop();
						System.out.println(e.getX() + " " + e.getY() + " stop!");
					}
				}
			}
		}
		
		for (Enemy e : enemy) {
			if (!e.isMovable() && e.getPause() <= 0) {
				e.setMove();
			}
		}
		
		changeState();
	}
	
	@Override
	public void changeState() {
		judge.setState(new EnemyRound(judge));
	}
}
