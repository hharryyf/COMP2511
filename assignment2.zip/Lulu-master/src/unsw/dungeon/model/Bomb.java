package unsw.dungeon.model;
// import javafx.scene.layout.GridPane;

public abstract class Bomb extends Pickupable{
	
	protected Dungeon dungeon;
	// private GridPane sqare;
	public Bomb(Dungeon dungeon, int x, int y) {
		super(x, y);
		this.dungeon = dungeon;
	}
	

	/**
	 * Set the bomb to active mode, throw exception if
	 * the bomb has not been picked up
	 */
	public abstract void lightUp();
}
