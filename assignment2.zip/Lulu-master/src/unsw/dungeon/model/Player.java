package unsw.dungeon.model;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;


/**
 * The player entity
 * 
 * @author Robert Clifton-Everest
 *
 */
public class Player extends Entity {

    private Dungeon dungeon;
    private Potion potion;
    private Sword sword;
    // bombs that are carried
    private List<Bomb> bombs;
   
    private List<Treasure> myTreasure;
    private Key key;
    
    private Goal goal = null;
    /**
     * Create a player positioned in square (x,y)
     * 
     * @param x
     * @param y
     */
    
    
    
    
    public Player(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
        this.bombs = new LinkedList<Bomb>();
        this.potion = null;
        this.sword = null;
        this.key=null;
        this.myTreasure = new LinkedList<>();
        // this.goal = new Goal();
    }
    
    
    public HashMap<String,Integer> getInventoryState(){
    	
    	
    	HashMap<String,Integer> inventory = new HashMap<String,Integer>();
    	
    	if(this.hasPotion()) {
    		inventory.put("Potion", this.potion.getRemained());
    	}else {
    		inventory.put("Potion", 0);
    	}
    	if(this.hasSword()) {
    		inventory.put("Sword", this.sword.getRemainhits());
    	}else {
    		inventory.put("Sword", 0);
    	}
    	if(this.hasKey()) {
    		inventory.put("Key", 1);
    	}else {
    		inventory.put("Key", 0);
    	}
    	inventory.put("Treasure", this.myTreasure.size());
    	inventory.put("Bomb", this.bombs.size());
    	return inventory;
    }
    
    public void dropBomb(Bomb tmp) {
    	this.bombs.remove(tmp);
    }
    //methods for keys
    
    public boolean hasKey() {
    	return (this.key != null);
    }
    
    /**
     * gain key
     * @param newK
     */
    
    private void gainKey(Key newK) {
    	if(this.hasKey())
    		throw new java.lang.Error("Player can only have one key");
    	this.key=newK;
    	//delete the key
    	newK.setShouldDie();
    }
    
    public void openDoor(Doors target) {
    	if (target == null) return;
    	this.key.open(target);
    	this.key=null;
    }
    
    /// methods for sword using, picking, killing
    /**
     * 
     * @return 1 for having a sword at the moment
     */
    public boolean hasSword() {
        return (this.sword != null);
    }

    /**
     * 
     * @param newS the new sword adding to the owner
     */
    private void gainSword(Sword newS) {
        // TODO: do something to delete the sword from the dungeon
        // set the owner of the sword
        newS.setOwner(this);
        newS.setShouldDie();
        this.sword = newS;
    }

    // delete the enemy from dungeon
    private void killEnermy() {
        List<Enemy> enemy = dungeon.getEnemy(getX(), getY());
        for (Enemy e : enemy) {
        	if (!e.getshouldDie()) {
	        	if (this.hasPotion()) {
	        		e.setShouldDie();
	        	} else if (this.hasSword()) {
	        		e.setShouldDie();
	        		this.sword.reduceHits();
	        	} else {
	        		this.setShouldDie();
	        	}
        	}
        }
        
        List<WildBeast> beasts = dungeon.getWildBeast(getX(), getY());
        if (!beasts.isEmpty() && !this.hasPotion()) this.setShouldDie();
    }

    /**
     * delete the sword that user owned
     */
    public void deleteSword() {
        this.sword = null;
    }

    /// methods for potion using,picking
    /**
     * 
     * @return true if player has a potion
     */
    public boolean hasPotion() {
        return (this.potion != null);
    }

    /**
     * gain a new potion
     * 
     * @param newP new potion
     */
    private void gainPotion(Potion newP) {
        // set the owner of the sword
        newP.setOwner(this);
        this.potion = newP;
    }

    /**
     * reduce potion effect by one
     */
    public void reducePotion() {
    	if (this.hasPotion()) {
    		this.potion.reduceEffect();
    		if (this.potion.getRemained() <= 0) {
    			this.potion = null;
    		}
        }
    }
    
    /**
     * pick up the treasure newT
     * @param newT
     */
    
    private void gainTreasure(Treasure newT) {
    	this.myTreasure.add(newT);
    	newT.setOwner(this);
    }
    
    /**
     * pick up the bomb
     * @param b
     */
    
    private void gainBomb(Bomb b) {
    	this.bombs.add(b);
    	b.setOwner(this);
    }
    
    /**
     * pickup everyting that's in the same cell as the player
     */
    
    public void pickup() {
    	//treasure
    	List<Treasure> treasures= this.dungeon.getTreasure(getX(), getY());
    	
    	for(Treasure tmp: treasures) {
    		this.gainTreasure(tmp);
    	}
    	
    	//potion
    	Potion p=dungeon.getPotion(getX(), getY());
    	if(p!=null) {
    		this.gainPotion(p);
    	}
    	
    	//sword
    	if(!this.hasSword()) {
    		Sword s=this.dungeon.getSword(getX(), getY());
    		if(s!=null)this.gainSword(s);
    	}
    	//key
    	if(!this.hasKey()) {
    		Key s=this.dungeon.getKey(getX(), getY());
    		if(s!=null)this.gainKey(s);
    	}
    	
    	//bomb
    	
    	List<Bomb> boooms= this.dungeon.getBomb(getX(), getY());
    	for(Bomb tmp: boooms) {
    		this.gainBomb(tmp);
    	}
    	
    }
    
    /**
     * 
     * @return true/false for the user to have bomb or not
     */
    
    public boolean hasBomb() {
    	return this.bombs.size()!=0;
    }



    public boolean canKill() {
        return this.hasPotion() || this.hasSword();
    }

    public void moveUp() {
    	int targetx = getX(), targety = getY() - 1;
    	
        if (couldMove(getX(), getY(), targetx, targety)) {
        	y().set(getY() - 1);
        	this.killEnermy();
        	this.openDoor(dungeon.getClosedDoor(getX(), getY()));
        }
            
    }

    public void moveDown() {
    	
    	int targetx = getX(), targety = getY() + 1;
    	
        if (couldMove(getX(), getY(), targetx, targety)) {
        	y().set(getY() + 1);
        	this.killEnermy();
        	this.openDoor(dungeon.getClosedDoor(getX(), getY()));
        }
    	
    }

    public void moveLeft() {
    	int targetx = getX() - 1, targety = getY();
    	
        if (couldMove(getX(), getY(), targetx, targety)) {
        	x().set(getX() - 1);
        	this.killEnermy();
        	this.openDoor(dungeon.getClosedDoor(getX(), getY()));
        }
    }

    public void moveRight() {
    	
    	int targetx = getX() + 1, targety = getY();
    	
        if (couldMove(getX(), getY(), targetx, targety)) {
        	x().set(getX() + 1);
        	this.killEnermy();
        	this.openDoor(dungeon.getClosedDoor(getX(), getY()));
        }
    }
    /**
     * light up a bomb
     */
    public void putBomb() {
    	if(!this.hasBomb()) return; 
    	// throw new java.lang.Error("cant put this here");
    	Bomb tmp  =this.bombs.remove(this.bombs.size()-1);
    	tmp.lightUp();
    }
    
    /**
     * give the user the goal, using composite pattern to implement
     * @param goal
     */
    
    public void setGoal(Goal goal) {
    	this.goal = goal;
    }
    /**
     * 
     * @return true/false for the player to complete the goals
     */
    public boolean completeGoal() {
    	if (goal == null) return true;
    	return goal.hasfinish();
    }
    
    /**
     * get the goal of the user, for debugging and unit testing
     * @return goal
     */
    
    public Goal getGoal() {
    	return this.goal;
    }
    
    /**
     * check whether the user can move into the cell (x, y) from (prevx, prevy)
     * @param x
     * @param y
     * @return boolean value
     */
    public boolean couldMove(int prevx, int prevy, int x, int y) {
    	if (!dungeon.withinBoundary(x, y)) return false;
    	if (dungeon.hasWall(x, y)) return false;
    	Doors door = dungeon.getClosedDoor(x, y);
    	if (door != null) {
    		if (!this.hasKey() || !this.key.canOpen(door)) return false;
    	}
    	
    	Boulder boulder = dungeon.getBoulder(x, y);
    	if (boulder != null) {
    		if (!dungeon.cellEmpty(2*x-prevx, 2*y -prevy)) return false;
    		boulder.x().set(2*x-prevx);
    		boulder.y().set(2*y-prevy);
    	}
    	return true;
    }
}
