package unsw.dungeon.model;

public class BasicTreasureGoal implements Goal {

	private Dungeon dungeon;
	public BasicTreasureGoal(Dungeon dungeon) {
		this.dungeon = dungeon;
	}

	
	
	@Override
	public boolean hasfinish() {
		return dungeon.finishTreasure();
	}
	
	@Override
	public String display(int depth) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0  ; i < depth; i++) {
			sb.append("\t");
		}
		return sb.append("[goal: treasure " + " complete " + this.hasfinish() + "]\n").toString();
	}


}
