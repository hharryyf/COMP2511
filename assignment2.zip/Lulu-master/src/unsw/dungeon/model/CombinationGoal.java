package unsw.dungeon.model;

import java.util.ArrayList;

public class CombinationGoal implements Goal {
	private ArrayList<Goal> subgoals;
	private boolean finishAll;
	private boolean finish;
	public CombinationGoal(Dungeon dungeon, boolean relation) {
		subgoals = new ArrayList<>();
		this.finishAll = relation;
		this.finish = true;
	}
	
	public void addSubgoal(Goal g) {
		this.subgoals.add(g);
	}
	

	@Override
	public String display(int depth) {
		
		
		StringBuilder sb = new StringBuilder();
		for (int i = 0 ; i < depth; i++) {
			sb.append("\t");
		}
		sb.append("subgoal: " + (finishAll ? "And" : "Or") + " [\n");
		for (Goal g : subgoals) {
			sb.append(g.display(depth + 1));
		}
		for (int i = 0 ; i < depth; i++) {
			sb.append("\t");
		}
		sb.append("] complete? " + finish + "\n");
		return sb.toString();
	}

	@Override
	public boolean hasfinish() {
		if (!finishAll) {
			this.finish = false;
			for (Goal g : subgoals) {
				if (g.hasfinish()) {
					this.finish = true;
					
				}
			}
			return this.finish;
		}
		
		this.finish = true;
		for (Goal g : subgoals) {
			if (!g.hasfinish()) {
				this.finish = false;
			}
		}
		return this.finish;
	}

}
