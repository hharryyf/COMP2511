package unsw.dungeon.model;

public class Key extends Pickupable {

	private int id;
	/**
	 * 
	 * @param x
	 * @param y
	 * @param door door that the key could open
	 */
	public Key(int x, int y,int id) {
		super(x, y);
		this.id=id;
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * check whether the key could open the door
	 * @param door
	 * @return true/false
	 */
	
	boolean canOpen(Doors door) {
		return (this.id==door.getId());
	}
	
	/**
	 * key open the door
	 * @param door
	 */
	
	public void open(Doors door) {
		door.open();
	}
	
	public int getId() {
		return this.id;
	}
}
