package unsw.dungeon.model;

import javafx.scene.image.Image;

public class Doors extends Entity {
	private boolean isopen;
	private int id;
	public Doors(int x, int y, int id) {
		super(x, y);
		this.isopen = false;
		this.id = id;
	}
	/**
	 * 
	 * @return true if the door is open, otherwise return false
	 */
	public boolean isOpen() {
		return this.isopen;
	}
	
	/**
	 * reset the door status to be open
	 */
	public void open() {
		this.isopen = true;
		if (this.getView() != null) {
			this.getView().setImage(new Image("open_door.png"));
		}
	}
	/**
	 * get the id of the current door
	 * @return an integer, id of the door
	 */
	public int getId() {
		return this.id;
	}
}
