package unsw.dungeon.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.image.ImageView;

/**
 * An entity in the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class Entity {

    // IntegerProperty is used so that changes to the entities position can be
    // externally observed.
    private IntegerProperty x, y;
    private ImageView view=null;
    // the entity should die and wiped out of the map in the next round or not
    private boolean shouldDie;
    /**
     * Create an entity positioned in square (x,y)
     * @param x
     * @param y
     */
    
    
    
    public Entity(int x, int y) {
        this.x = new SimpleIntegerProperty(x);
        this.y = new SimpleIntegerProperty(y);
        this.shouldDie = false;
    }

    public IntegerProperty x() {
        return x;
    }

    public IntegerProperty y() {
        return y;
    }

    public int getY() {
        return y().get();
    }

    public int getX() {
        return x().get();
    }
    /**
     * set the entity should be wiped out from the dungeon
     */
    public void setShouldDie() {
    	this.shouldDie = true;
    }
    /**
     * get whether the entity should die
     * @return true/false
     */
    public boolean getshouldDie() {
    	return this.shouldDie;
    }

	public ImageView getView() {
		return view;
	}

	public void setView(ImageView view) {
		this.view = view;
	}
    
    
}
