package unsw.dungeon.model;

public class BasicBoulderGoal implements Goal {

	private Dungeon dungeon;
	public BasicBoulderGoal(Dungeon dungeon) {
		this.dungeon = dungeon;
	}

	
	
	@Override
	public boolean hasfinish() {
		return dungeon.finishBoulder();
	}
	
	
	@Override
	public String display(int depth) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0  ; i < depth; i++) {
			sb.append("\t");
		}
		return sb.append("[goal: boulder " + " complete " + this.hasfinish() + "]\n").toString();
	}
}
