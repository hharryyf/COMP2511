package unsw.dungeon.model;

public class Exit extends Entity {

	public Exit(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
}
