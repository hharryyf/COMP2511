package unsw.dungeon.model;

public class EnemyStop implements EnemyState { 
	private Enemy enemy;
	public EnemyStop(Enemy enemy) {
		this.enemy = enemy;
	}
	
	// change state and do nothing
	@Override
	public void move() {
		enemy.setPause(enemy.getPause() - 1);
	}
}
