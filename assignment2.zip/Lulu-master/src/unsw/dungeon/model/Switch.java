package unsw.dungeon.model;

public class Switch extends Entity {
	private boolean triggers;
	public Switch(int x, int y) {
		super(x, y);
		this.setTriggers(false);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * check whether the swithes are triggered
	 * @return true/false
	 */
	
	public boolean isTriggers() {
		return triggers;
	}
	
	/**
	 * set the state of the switches
	 * @param triggers represents true false
	 */
	
	public void setTriggers(boolean triggers) {
		this.triggers = triggers;
	}
}
