package unsw.dungeon.model;

import java.util.List;

public class Judge {
	private Dungeon dungeon;
	private JudgeState judgestate;
	
	public Judge(Dungeon dungeon) {
		this.dungeon = dungeon;
		this.judgestate = new UserRound(this);
	}
	
	public Dungeon getDungeon() {
		return dungeon;
	}
	
	/**
	 * check whether the game should end
	 * @return user win/user lost/draw
	 */
	
	public String judgeRound() {
		return judgestate.gameResult();
	}
	
	/**
	 * wipe out the dead entities
	 */
	
	public void updateBoard() {
		judgestate.changeLocation();
	}
	
	/**
	 * change the state of the judge whether it is enemyround or user round
	 * @param state
	 */
	
	public void setState(JudgeState state) {
		this.judgestate = state;
	}
	
	public List<Enemy> getAllEnemy() {
		return dungeon.getEnemy();
	}
	
	public Player getPlayer() {
		return dungeon.getPlayer();
	}
}
