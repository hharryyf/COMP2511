package unsw.dungeon.model;

public class Boulder extends Entity {
	
	public Boulder(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
	
}
