package unsw.dungeon;

import java.io.IOException;

import javafx.application.Application;
import javafx.stage.Stage;
import unsw.dungeon.controller.StartingScreen;

public class DungeonApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
    	
    	StartingScreen startscreen = new StartingScreen(primaryStage);
    	startscreen.start();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
