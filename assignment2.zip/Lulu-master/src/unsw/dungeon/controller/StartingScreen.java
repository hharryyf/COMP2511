package unsw.dungeon.controller;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class StartingScreen {
	private Stage stage;
	private StartingController controller;
	private Scene scene;
	public StartingScreen(Stage stage) throws IOException {
		this.stage = stage;
		stage.setTitle("Dungeon Game");
		controller = new StartingController(stage);
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/InitialPage.fxml"));
	    loader.setController(controller);
	    Parent root = loader.load();
	    root.requestFocus();
	    scene = new Scene(root, 400, 300);
	}
	
	public void start() {
		 stage.setScene(scene);
	     stage.show();
	}
}
