package unsw.dungeon.controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import unsw.dungeon.model.BasicBoulderGoal;
import unsw.dungeon.model.BasicEnemyGoal;
import unsw.dungeon.model.BasicExitGoal;
import unsw.dungeon.model.BasicTreasureGoal;
import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.CombinationGoal;
import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Entity;
import unsw.dungeon.model.Exit;
import unsw.dungeon.model.Goal;
import unsw.dungeon.model.Key;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Potion;
import unsw.dungeon.model.Switch;
import unsw.dungeon.model.Sword;
import unsw.dungeon.model.Treasure;
import unsw.dungeon.model.Wall;
import unsw.dungeon.model.WildBeast;
import unsw.dungeon.model.UnlitBomb;

/**
 * Loads a dungeon from a .json file.
 *
 * By extending this class, a subclass can hook into entity creation. This is
 * useful for creating UI elements with corresponding entities.
 *
 * @author Robert Clifton-Everest
 *
 */
public abstract class DungeonLoader {

    private JSONObject json;

    public DungeonLoader(String filename) throws FileNotFoundException {
        json = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
    }

    /**
     * Parses the JSON to create a dungeon.
     * @return
     */
    public Dungeon load() {
        int width = json.getInt("width");
        int height = json.getInt("height");

        Dungeon dungeon = new Dungeon(width, height);

        JSONArray jsonEntities = json.getJSONArray("entities");

        for (int i = 0; i < jsonEntities.length(); i++) {
            loadEntity(dungeon, jsonEntities.getJSONObject(i));
        }
        
        dungeon.getPlayer().setGoal(parseGoal(dungeon, json.getJSONObject("goal-condition")));
        return dungeon;
    }

    private void loadEntity(Dungeon dungeon, JSONObject json) {
        String type = json.getString("type");
        int x = json.getInt("x");
        int y = json.getInt("y");
        Random r = new Random();
        Entity entity = null;
        switch (type) {
        case "player":
            Player player = new Player(dungeon, x, y);
            dungeon.setPlayer(player);
            onLoad(player);
            entity = player;
            break;
        case "wall":
            Wall wall = new Wall(x, y);
            onLoad(wall);
            entity = wall;
            dungeon.addWall(wall);
            break;
        // TODO Handle other possible entities
        case "enemy":
        	int k = r.nextInt(4);
        	Enemy enemy;
        	if (k == 1) {
        		enemy = new Enemy(dungeon, x, y);
        	} else if (k == 2) {
        		enemy = new Enemy(dungeon, x, y, 1);
        	} else {
        		enemy = new Enemy(dungeon, x, y, 11);
        	}
        	onLoad(enemy);
        	dungeon.addEnemy(enemy);
        	entity = enemy;
        	break;
        case "exit":
        	Exit exit = new Exit(x, y);
        	onLoad(exit);
        	dungeon.addExit(exit);
        	entity = exit;
        	break;
        case "treasure":
        	Treasure treasure = new Treasure(x, y);
        	onLoad(treasure);
        	dungeon.addTreature(treasure);
        	entity = treasure;
        	break;
        case "invincibility":
        	Potion potion = new Potion(x, y);
        	onLoad(potion);
        	dungeon.addPotion(potion);
        	entity = potion;
        	break;
        case "bomb":
        	Bomb bomb = new UnlitBomb(dungeon, x, y);
        	onLoad(bomb);
        	dungeon.addBomb(bomb);
        	entity = bomb;
        	break;
        case "sword":
        	Sword sword = new Sword(x, y);
        	onLoad(sword);
        	dungeon.addSword(sword);
        	entity = sword;
        	break;
        case "switch":
        	Switch sw = new Switch(x, y);
        	onLoad(sw);
        	dungeon.addSwich(sw);
        	entity = sw;
        	break;
        case "boulder":
        	Boulder bd = new Boulder(x, y);
        	onLoad(bd);
        	dungeon.addBoulder(bd);
        	entity = bd;
        	break;
        case "door":
        	int id = json.getInt("id");
        	Doors door = new Doors(x, y, id);
        	onLoad(door);
        	dungeon.addDoor(door);
        	entity = door;
        	break;
        case "key":
        	int id2 = json.getInt("id");
        	Key key = new Key(x, y, id2);
        	onLoad(key);
        	dungeon.addKey(key);
        	entity = key;
        	break;
        case "beast":
        	WildBeast bt = new WildBeast(dungeon, x, y);
        	onLoad(bt);
        	dungeon.addWildBeast(bt);
        	entity = bt;
        	break;
        default:
        	break;
        }
        if (entity != null) {
        	dungeon.addEntity(entity);
        }
    }

    public abstract void onLoad(Entity player);

    public abstract void onLoad(Wall wall);
    
    public abstract void onLoad(Enemy enemy); 
    
    public abstract void onLoad(Exit exit);
    
    public abstract void onLoad(Sword sword);
    
    public abstract void onLoad(Treasure treasure);
    
    public abstract void onLoad(Boulder bd);
    public abstract void onLoad(Switch sw);
    public abstract void onLoad(Potion potion);
    public abstract void onLoad(Bomb bomb);
    public abstract void onLoad(Key key);
    public abstract void onLoad(Doors door);
    public abstract void onLoad(WildBeast wb);
    // TODO Create additional abstract methods for the other entities
    
    
    private Goal parseGoal(Dungeon dungeon, JSONObject jb) {
    	if (jb.getString("goal").compareTo("AND") == 0) {
    		CombinationGoal goal = new CombinationGoal(dungeon, true);
    		JSONArray arr = jb.getJSONArray("subgoals");
    		for (int i = 0 ; i < arr.length(); i++) {
    			goal.addSubgoal(parseGoal(dungeon, arr.getJSONObject(i)));
    		}
    		return goal;
    	} else if (jb.getString("goal").compareTo("OR") == 0) {
    		CombinationGoal goal = new CombinationGoal(dungeon, false);
    		JSONArray arr = jb.getJSONArray("subgoals");
    		for (int i = 0 ; i < arr.length(); i++) {
    			goal.addSubgoal(parseGoal(dungeon, arr.getJSONObject(i)));
    		}
    		return goal;
    	} else if (jb.getString("goal").compareTo("boulders") == 0) {
    		return new BasicBoulderGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("enemies") == 0) {
    		return new BasicEnemyGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("treasure") == 0) {
    		return new BasicTreasureGoal(dungeon);
    	} else if (jb.getString("goal").compareTo("exit") == 0) {
    		return new BasicExitGoal(dungeon);
    	}
    	return null;
    }
}
