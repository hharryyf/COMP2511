package unsw.dungeon.controller;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CustomerScreen {
	private CustomerController controller;
	private Scene scene;
	private Stage stage;
	public CustomerScreen(Stage stage) throws IOException {
		this.stage = stage;
		stage.setTitle("Dungeon Game");
		controller = new CustomerController(stage);
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/CustomerView.fxml"));
	    loader.setController(controller);
	    Parent root = loader.load();
	    root.requestFocus();
	    scene = new Scene(root, 1200, 1200);
	}
	
	public void start() {
		 stage.setScene(scene);
	     stage.show();
	}
}
