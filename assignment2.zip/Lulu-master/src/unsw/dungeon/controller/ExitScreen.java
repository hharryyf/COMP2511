package unsw.dungeon.controller;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ExitScreen {
	private Stage stage;
	private Scene scene;
	public ExitScreen(Stage stage, int state) throws IOException {
		this.stage = stage;
		stage.setTitle("Dungeon Game");
		ExitController controller = new ExitController(stage, state);
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/ExitView.fxml"));
	    loader.setController(controller);
	    Parent root = loader.load();
	    root.requestFocus();
	    scene = new Scene(root, 1000, 1200);
	}
	
	public void start() {
		stage.setScene(scene);
		stage.show();
	}
}
