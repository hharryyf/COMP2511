package unsw.dungeon.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.sun.media.jfxmedia.AudioClip;
import com.sun.media.jfxmedia.Media;

import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Judge;
import unsw.dungeon.model.Player;

/**
 * A JavaFX controller for the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class DungeonController {
	
	@FXML
	private Button viewenemy;
	
    @FXML
    private GridPane squares;
    
    @FXML
    private GridPane collection;
    
    @FXML
    private Text goalstate;
    
    @FXML 
    private IntegerProperty sword=new SimpleIntegerProperty(0);
    
    
    private HashMap<String,Text> inventory = new HashMap<String,Text>(); 
    
    
    private List<ImageView> initialEntities;

    private Player player;

    private Dungeon dungeon;
    private Judge judge;
    private IntegerProperty gameover;
    private IntegerProperty nummoves;
    
    @FXML
    private Text gamecounter;
    
    private Stage primaryStage;
    
    public DungeonController(Dungeon dungeon, List<ImageView> initialEntities) {
        this.dungeon = dungeon;
        dungeon.setObserver(this);
        this.player = dungeon.getPlayer();
        this.initialEntities = new ArrayList<>(initialEntities);
        judge = new Judge(dungeon);
        this.gameover = new SimpleIntegerProperty(0);
        this.nummoves = new SimpleIntegerProperty(4 * dungeon.getWidth() * dungeon.getHeight());
        
        this.nummoves.addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				if (newValue.intValue() <= 0) {
					gameover.setValue(-2);
				}
			}
        	
        });
        
        this.gameover.addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
            	if(newValue.intValue() ==1) {
            		// win 
            		updateInventory(player.getInventoryState());
            		System.out.println("Win the game");
            		Alert win = new Alert(AlertType.WARNING);
            		win.setTitle("Winner");
            		win.setContentText("Yeah. Exit");
            		win.showAndWait();
            		ExitScreen exitscreen;
					try {
						exitscreen = new ExitScreen(primaryStage, 1);
						exitscreen.start();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            		
            		//Platform.exit();
            		//System.exit(0);
            	}else if (newValue.intValue()==-1) {
            		// lose
            		System.out.println("Lost");
            		updateInventory(player.getInventoryState());
            		Alert loser = new Alert(AlertType.WARNING);
            		loser.setTitle("Loser");
            		
            		loser.setContentText("Lose. Exit");
            		stop();
            		loser.showAndWait();
            		ExitScreen exitscreen;
					try {
						exitscreen = new ExitScreen(primaryStage, 0);
						exitscreen.start();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            		
            		//Platform.exit();
            		//System.exit(0);
            	} else if (newValue.intValue()==-2) {
            		// lose
            		System.out.println("Lost");
            		updateInventory(player.getInventoryState());
            		Alert loser = new Alert(AlertType.WARNING);
            		loser.setTitle("Loser due to timeout");
            		loser.setContentText("Lose. Exit");
            		stop();
            		loser.showAndWait();
            		ExitScreen exitscreen;
					try {
						exitscreen = new ExitScreen(primaryStage, 0);
						exitscreen.start();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            		
            	}
                
            }
        });
       
    }
    
    public void updateView(List<ImageView> deletes,HashMap<String,Integer> inventory) {
    	for(ImageView current : deletes) {
    		squares.getChildren().remove(current);
    	}
    	
    	updateInventory(inventory);
    }
    
    private void updateInventory(HashMap<String,Integer> inventory) {
    	this.inventory.get("Key").setText(Integer.toString(inventory.get("Key")));
    	this.inventory.get("Sword").setText(Integer.toString(inventory.get("Sword")));
    	this.inventory.get("Potion").setText(Integer.toString(inventory.get("Potion")));
    	this.inventory.get("Bomb").setText(Integer.toString(inventory.get("Bomb")));
    	this.inventory.get("Treasure").setText(Integer.toString(inventory.get("Treasure")));
    }
    
    @FXML
    public void initialize() {
        Image ground = new Image("/dirt_0_new.png");

        // Add the ground first so it is below all other entities
        for (int x = 0; x < dungeon.getWidth(); x++) {
            for (int y = 0; y < dungeon.getHeight(); y++) {
                squares.add(new ImageView(ground), x, y);
            }
        }
        
        
        for (ImageView entity : initialEntities) {
            squares.getChildren().add(entity);
        }
        
        ImageView view = new ImageView(new Image("/greatsword_1_new.png"));
        collection.add(view, 0, 0);
        this.inventory.put("Sword", new Text("0"));
        collection.add(this.inventory.get("Sword"), 1, 0);
        view = new ImageView(new Image("/key.png"));
        collection.add(view, 0, 1);
        this.inventory.put("Key", new Text("0"));
        collection.add(this.inventory.get("Key"), 1, 1);
        view = new ImageView(new Image("/bomb_unlit.png"));
        collection.add(view, 0, 2);
        this.inventory.put("Bomb", new Text("0"));
        collection.add(this.inventory.get("Bomb"), 1, 2);
        view = new ImageView(new Image("/brilliant_blue_new.png"));
        collection.add(view, 0, 3);
        this.inventory.put("Potion", new Text("0"));
        collection.add(this.inventory.get("Potion"), 1, 3);
        view = new ImageView(new Image("/gold_pile.png"));
        collection.add(view, 0, 4);
        this.inventory.put("Treasure", new Text("0"));
        collection.add(this.inventory.get("Treasure"), 1, 4);
        this.gamecounter.setText(String.valueOf(this.nummoves.intValue()));
    }

    @FXML
    public void handleKeyPress(KeyEvent event) {
    	if (player == null || player.getGoal() == null) return;
    	if (gameover.get() != 0) return;
        switch (event.getCode()) {
	        case UP:
	            player.moveUp();
	            break;
	        case DOWN:
	            player.moveDown();
	            break;
	        case LEFT:
	            player.moveLeft();
	            break;
	        case RIGHT:
	            player.moveRight();
	            
	            break;
	        case B:
	        	player.putBomb();
	        	break;
	        case P:
	        	player.pickup();
	        	break;
	        default:
	            break;
        }
        
        String str = judge.judgeRound();
        this.checkEnd(str);
        
        goalstate.setText(player.getGoal().display(0));
        System.out.println(str);
        judge.updateBoard();
        dungeon.enemyMove();
        
        str = judge.judgeRound();
        this.checkEnd(str);
        goalstate.setText(player.getGoal().display(0));
        System.out.println(str);
        judge.updateBoard();
        this.gamecounter.setText(String.valueOf(this.nummoves.get() - 1));
        this.nummoves.set(this.nummoves.get() - 1);
    }
    
    
	public void addView(ImageView view, int x, int y) {
		squares.add(view, x, y);
	}
    
	public void updateBombView(ImageView view, int timer) {
		if (view != null) {
			if (timer == 0) {
				view.setImage(new Image("/bomb_lit_4.png"));
			} else if (timer == 1) {
				view.setImage(new Image("/bomb_lit_3.png"));
			} else if (timer == 2) {
				view.setImage(new Image("/bomb_lit_2.png"));
			}
		}
	}
	
	@FXML
	public void handleView(ActionEvent event) {
		this.gamecounter.setText(String.valueOf(this.nummoves.get() / 2));
		this.nummoves.set(this.nummoves.get() / 2);
		if (this.gameover.get() != 0) return;
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setTitle("Enemy View");
		GridPane grid = new GridPane();
		grid.setVgap(1.0);
		grid.setHgap(1.0);
		int i, j;
		for (i = 0 ; i < dungeon.getWidth(); i++) {
			for (j = 0 ; j < dungeon.getHeight(); j++) {
				Text text = new Text("0");
				if (i == player.getX() && j == player.getY()) {
					text.setText("P");
				}
				
				int k = dungeon.getEnemy(i, j).size();
				if (k != 0) {
					text.setText(String.valueOf(k));
				}
				grid.add(text, i, j);
			}
		}
		Scene scene = new Scene(grid,400,400);
		stage.setScene(scene);
		stage.showAndWait();
	}
	private void checkEnd(String str) {
		if (str.compareTo("Draw!") != 0) {
        	System.out.println(str);
        	if(str.compareTo("User Lost!") == 0) {
        		
        		gameover.setValue(-1);
        		return;
        	}
        	
        	goalstate.setText(player.getGoal().display(0));
        	gameover.setValue(1);
        	return;
        }
	}
	

	private void stop() {
		
		for(long  i=0; i<100000000;i++) {
			for(long  j=0; j<10;j++) {

			}
		}
	}
	
	public void setStage(Stage stage) {
		this.primaryStage = stage;
	}
}

