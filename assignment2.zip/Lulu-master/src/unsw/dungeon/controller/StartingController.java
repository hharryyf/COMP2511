package unsw.dungeon.controller;

import java.io.IOException;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class StartingController {
	public StartingController(Stage primaryStage) {
		this.stage = primaryStage;
	}
	@FXML
	private Button lowbutton;
	
	@FXML
	private Button mediumbutton;
	
	@FXML
	private Button highbutton;
	
	@FXML
	private Button selfbutton;
	
	private Stage stage;
	
	@FXML
	public void pressLow(ActionEvent event) throws IOException {
		DungeonControllerLoader dungeonLoader = new DungeonControllerLoader("maze.json");

        DungeonController controller = dungeonLoader.loadController();
        controller.setStage(stage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/DungeonView.fxml"));
        loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root, 1200, 1200);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
	}
	
	@FXML
	public void pressMedium(ActionEvent event) throws IOException {
		DungeonControllerLoader dungeonLoader = new DungeonControllerLoader("boulders.json");

        DungeonController controller = dungeonLoader.loadController();
        controller.setStage(stage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/DungeonView.fxml"));
        loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root, 1200, 1200);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
	}
	
	@FXML
	public void pressHigh(ActionEvent event) throws IOException {
		String[] filename = {"advanced.json", "advance2.json"};
		Random r = new Random();
		
		DungeonControllerLoader dungeonLoader = new DungeonControllerLoader(filename[r.nextInt(2)]);

        DungeonController controller = dungeonLoader.loadController();
        controller.setStage(stage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/DungeonView.fxml"));
        loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root, 1200, 1200);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
	}
	
	@FXML
	public void pressSelf(ActionEvent event) throws IOException {
		CustomerScreen screen = new CustomerScreen(stage);
		screen.start();
	}
	
	
	
}
