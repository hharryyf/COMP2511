package unsw.dungeon.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ExitController {
	private Stage stage;
	private int state;
	
	@FXML
    private Button exitbutton;

    @FXML
    private Button restartbutton;

    @FXML
    private Pane exitimage;

    @FXML
    public void handleexit(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    public void handlerestart(ActionEvent event) throws IOException {
    	StartingScreen startscreen = new StartingScreen(stage);
    	startscreen.start();
    }
    
    @FXML
    public void initialize() {
    	ImageView view;
    	if (state == 0) {
    		view = new ImageView(new Image("/dead.png"));
    	} else {
    		view = new ImageView(new Image("/win.jpg"));
    	}
    	exitimage.getChildren().add(view);
    }
    
    public ExitController(Stage stage, int state) {
		this.stage = stage;
		this.state = state;
	}
}
