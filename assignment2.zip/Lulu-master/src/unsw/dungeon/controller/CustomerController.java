package unsw.dungeon.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import unsw.dungeon.model.BasicBoulderGoal;
import unsw.dungeon.model.BasicEnemyGoal;
import unsw.dungeon.model.BasicExitGoal;
import unsw.dungeon.model.BasicTreasureGoal;
import unsw.dungeon.model.Bomb;
import unsw.dungeon.model.Boulder;
import unsw.dungeon.model.CombinationGoal;
import unsw.dungeon.model.Doors;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Enemy;
import unsw.dungeon.model.Entity;
import unsw.dungeon.model.Exit;
import unsw.dungeon.model.Goal;
import unsw.dungeon.model.Key;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.Potion;
import unsw.dungeon.model.Switch;
import unsw.dungeon.model.Sword;
import unsw.dungeon.model.Treasure;
import unsw.dungeon.model.UnlitBomb;
import unsw.dungeon.model.Wall;
import unsw.dungeon.model.WildBeast;

public class CustomerController {
	private Stage stage;
	@FXML
	private GridPane choice;
	
	@FXML
	private Button finishbutton;
	
	@FXML 
	private Button confirmbutton;
	
	@FXML
	private ComboBox<Integer> widthid;
	
	@FXML
	private ComboBox<Integer> heightid;
	
	@FXML
	private ComboBox<Integer> playerx;
	
	@FXML
	private ComboBox<Integer> playery;
	
	@FXML
	private Text errormsg;
	
	@FXML
	private ComboBox<String> goalid;
	
	@FXML
	private GridPane picdisplay;
	
	private ObservableList<Integer> list = FXCollections.observableArrayList(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18);
	
	private ObservableList<String> entitychoice = FXCollections.observableArrayList("","wall","key1","key2","key3","door1","door2","door3","weakenemy","mediumenemy","strongenemy","potion","wildbeast","exit","treasure","switch","boulder","bomb","sword");
	
	private ObservableList<String> goallist = FXCollections.observableArrayList("go to the exit", "get all treasures", "kill all enemy", "have boulder on all switches", "exit and kill enemy", "exit and collect all treasure", "exit and boulder on switch", "exit and enemy and treasure");
	
	private int width = -1;
	private int height = -1;
	private int px = -1;
	private int py = -1;
	
	private ArrayList<ArrayList<ComboBox<String>>> boxlist;
	
	private Dungeon dungeon;
	private List<ImageView> entities;
	
	private Image playerImage;
    private Image wallImage;
    private Image enemyImage;
    private Image exitImage;
    private Image swordImage;
    private Image treasureImage;
    private Image potionImage;
    private Image bombImage;
    private Image boulderImage;
    private Image switchImage;
    private Image doorImage;
    private Image keyImage;
    private Image dogImage;
	private Image emptyImage;
	private Image key1Image;
	private Image key2Image;
	private Image key3Image;
	private Image door1Image;
	private Image door2Image;
	private Image door3Image;
	
	
	@FXML
	public void handleConfirm(ActionEvent event) {
		if (width == -1 || height == -1 || px == -1 || py == -1) {
			errormsg.setText("Select width,height, playerx, playery to continue");
			return;
		}
		
		if (px >= width || py >= height || px < 0 || py < 0 || width <= 0 || height <= 0) {
			errormsg.setText("The player is out of the boundary or width= 0, height=0");
			return;
		}
		
		boxlist = new ArrayList<>();
		
		
		for (int i = 0 ; i < width; i++) {
			boxlist.add(new ArrayList<>());
			for (int j = 0 ; j < height; j++) {
				boxlist.get(i).add(new ComboBox<>());
				boxlist.get(i).get(j).setPrefWidth(150.0);
				if (i == px && j == py) {
					boxlist.get(i).get(j).setPromptText("player");
					boxlist.get(i).get(j).setValue("player");
				} else {
					boxlist.get(i).get(j).setItems(entitychoice);
					boxlist.get(i).get(j).setPromptText("select entity");
				}
				choice.add(boxlist.get(i).get(j), i, j);
			}
		}
		
		for (int i = 0 ; i < width; i++) {
			for (int j = 0 ; j < height; j++) {
				boxlist.get(i).get(j).setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent arg0) {
						picdisplay.getChildren().clear();
						for (int i = 0 ; i < width; i++) {
							for (int j = 0 ; j < height; j++) {
								picdisplay.add(loadpicture(boxlist.get(i).get(j).getValue()), i, j);
							}
						}
					}
				});
			}
		}
		
		errormsg.setText("Please select all possible the entities you want and click finish");
		this.playerx.setDisable(true);
		this.playery.setDisable(true);
		this.widthid.setDisable(true);
		this.heightid.setDisable(true);
		confirmbutton.setDisable(true);
		goalid.setDisable(false);
		finishbutton.setDisable(false);
	}
	
	private Node loadpicture(String value) {
		if (value == null || value.compareTo("") == 0) return new ImageView(this.emptyImage);
		switch(value) {
		case "player":
			return new ImageView(this.playerImage);
		case "wall":
			return new ImageView(this.wallImage);
		case "key1":
			return new ImageView(this.key1Image);
		case "key2":
			return new ImageView(this.key2Image);
		case "key3":
			return new ImageView(this.key3Image);
		case "door1":
			return new ImageView(this.door1Image);
		case "door2":
			return new ImageView(this.door2Image);
		case "door3":
			return new ImageView(this.door3Image);
		case "weakenemy":
			return new ImageView(this.enemyImage);
		case "mediumenemy":
			return new ImageView(this.enemyImage);
		case "strongenemy":
			return new ImageView(this.enemyImage);
		case "potion":
			return new ImageView(this.potionImage);
		case "wildbeast":
			return new ImageView(this.dogImage);
		case "exit":
			return new ImageView(this.exitImage);
		case "treasure":
			return new ImageView(this.treasureImage);
		case "switch":
			return new ImageView(this.switchImage);
		case "boulder":
			return new ImageView(this.boulderImage);
		case "bomb":
			return new ImageView(this.bombImage);
		case "sword":
			return new ImageView(this.swordImage);
		default:
			break;
		}
		return new ImageView(this.emptyImage);
	}
	
	@FXML
	public void handleFinish(ActionEvent event) throws IOException {
		if (goalid.getValue() == null) {
			errormsg.setText("please specify your goal before you click finish");
			return;
		}
		dungeon = new Dungeon(width, height);
		for (int i = 0 ; i < width; i++) {
			for (int j = 0 ; j < height; j++) {
				loadEntity(boxlist.get(i).get(j).getValue(), i, j);
			}
		}
		
		Goal g = processGoal(goalid.getValue());
		dungeon.getPlayer().setGoal(g);
		finishbutton.setDisable(true);
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../../../unsw/dungeon/view/DungeonView.fxml"));
		DungeonController controller = new DungeonController(dungeon, entities);
		controller.setStage(stage);
		loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root, 1200, 1200);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
		
		
	}
	
	private Goal processGoal(String value) {
		CombinationGoal g = new CombinationGoal(dungeon, true);
		switch (value) {
		/*  "exit and enemy and treasure"*/
		case "go to the exit":
			g.addSubgoal(new BasicExitGoal(dungeon));
			break;
		case "get all treasures":
			g.addSubgoal(new BasicTreasureGoal(dungeon));
			break;
		case "kill all enemy":
			g.addSubgoal(new BasicEnemyGoal(dungeon));
			break;
		case "have boulder on all switches":
			g.addSubgoal(new BasicBoulderGoal(dungeon));
			break;
		case "exit and kill enemy":
			g.addSubgoal(new BasicEnemyGoal(dungeon));
			g.addSubgoal(new BasicExitGoal(dungeon));
			break;
		case "exit and collect all treasure":
			g.addSubgoal(new BasicTreasureGoal(dungeon));
			g.addSubgoal(new BasicExitGoal(dungeon));
			break;
		case "exit and boulder on switch":
			g.addSubgoal(new BasicBoulderGoal(dungeon));
			g.addSubgoal(new BasicExitGoal(dungeon));
			break;
		case "exit and enemy and treasure":
			g.addSubgoal(new BasicEnemyGoal(dungeon));
			g.addSubgoal(new BasicTreasureGoal(dungeon));
			g.addSubgoal(new BasicExitGoal(dungeon));
			break;
		}
		return g;
	}

	private void loadEntity(String token, int x, int y) {
		if (token == null || token.length() == 0) return;
		Entity entity = null;
        switch (token) {
        case "player":
            Player player = new Player(dungeon, x, y);
            dungeon.setPlayer(player);
            onLoad(player);
            entity = player;
            break;
        case "wall":
        	Wall wall = new Wall(x, y);
        	dungeon.addWall(wall);
        	onLoad(wall);
        	entity = wall;
        	break;
        case "weakenemy":
        	Enemy enemy = new Enemy(dungeon, x, y);
        	dungeon.addEnemy(enemy);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "mediumenemy":
        	enemy = new Enemy(dungeon, x, y, 1);
        	dungeon.addEnemy(enemy);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "strongenemy":
        	enemy = new Enemy(dungeon, x, y, 14);
        	dungeon.addEnemy(enemy);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "potion":
        	Potion potion = new Potion(x, y);
        	dungeon.addPotion(potion);
        	onLoad(potion);
        	entity = potion;
        	break;
        case "exit":
        	Exit exit = new Exit(x, y);
        	dungeon.addExit(exit);
        	onLoad(exit);
        	entity = exit;
        	break;
        case "wildbeast":
        	WildBeast beast = new WildBeast(dungeon, x, y);
        	dungeon.addWildBeast(beast);
        	onLoad(beast);
        	entity = beast;
        	break;
        case "switch":
        	Switch switches = new Switch(x, y);
        	dungeon.addSwich(switches);
        	onLoad(switches);
        	entity = switches;
        	break;
        case "treasure":
        	Treasure tr = new Treasure(x, y);
        	dungeon.addTreature(tr);
        	onLoad(tr);
        	entity = tr;
        	break;
        case "boulder":
        	Boulder bd = new Boulder(x, y);
        	dungeon.addBoulder(bd);
        	onLoad(bd);
        	entity = bd;
        	break;
        case "bomb":
        	Bomb bm = new UnlitBomb(dungeon, x, y);
        	dungeon.addBomb(bm);
        	onLoad(bm);
        	entity = bm;
        	break;
        case "sword":
        	Sword sw = new Sword(x, y);
        	dungeon.addSword(sw);
        	onLoad(sw);
        	entity = sw;
        	break;
        case "key1":
        	Key key = new Key(x, y, 1);
        	dungeon.addKey(key);
        	onLoad(key);
        	entity = key;
        	break;
        case "key2":
        	key = new Key(x, y, 2);
        	dungeon.addKey(key);
        	onLoad(key);
        	entity = key;
        	break;
        case "key3":
        	key = new Key(x, y, 3);
        	dungeon.addKey(key);
        	onLoad(key);
        	entity = key;
        	break;
        case "door1":
        	Doors dr = new Doors(x, y, 1);
        	dungeon.addDoor(dr);
        	onLoad(dr);
        	entity = dr;
        	break;
        case "door2":
        	dr = new Doors(x, y, 2);
        	dungeon.addDoor(dr);
        	onLoad(dr);
        	entity = dr;
        	break;
        case "door3":
        	dr = new Doors(x, y, 3);
        	dungeon.addDoor(dr);
        	onLoad(dr);
        	entity = dr;
        	break;
        default:
        	break;
        }
        if (entity != null) {
        	dungeon.addEntity(entity);
        }
    }
	
	public void onLoad(Entity player) {
        ImageView view = new ImageView(playerImage);
        addEntity(player, view);
    }
	
    public void onLoad(Wall wall) {
        ImageView view = new ImageView(wallImage);
        addEntity(wall, view);
    }
    
    public void onLoad(Enemy enemy) {
    	ImageView view = new ImageView(enemyImage);
    	addEntity(enemy, view);
    }
    
    public void onLoad(Exit exit) {
    	ImageView view = new ImageView(exitImage);
    	addEntity(exit, view);
    }
    
    public void onLoad(Sword sword) {
    	ImageView view = new ImageView(swordImage);
    	addEntity(sword, view);
    }
    
    public void onLoad(Treasure treasure) {
    	ImageView view = new ImageView(treasureImage);
    	addEntity(treasure, view);
    }
    
    public void onLoad(Potion potion) {
    	ImageView view = new ImageView(potionImage);
    	addEntity(potion, view);
    }
    
    public void onLoad(Bomb bomb) {
    	ImageView view = new ImageView(bombImage);
    	addEntity(bomb, view);
    }
    
    public void onLoad(Boulder bd) {
    	ImageView view = new ImageView(boulderImage);
    	addEntity(bd, view);
    }
    
	public void onLoad(Switch sw) {
    	ImageView view = new ImageView(switchImage);
    	addEntity(sw, view);
	}
    
	public void onLoad(Key key) {
    	ImageView view;
    	if (key.getId() == 1) {
    		view = new ImageView(key1Image); 
    	} else if (key.getId() == 2) {
    		view = new ImageView(key2Image);
    	} else {
    		view = new ImageView(key3Image);
    	}
    	addEntity(key, view);
	}

	public void onLoad(Doors door) {
		ImageView view; 
		if (door.getId() == 1) {
			view = new ImageView(door1Image);
		} else if (door.getId() == 2) {
			view = new ImageView(door2Image);
		} else {
			view = new ImageView(door3Image);
		}
    	addEntity(door, view);
	}
    
	public void onLoad(WildBeast wb) {
		ImageView view = new ImageView(dogImage);
    	addEntity(wb, view);
	}
    
	
	private void addEntity(Entity entity, ImageView view) {
    	
    	entity.setView(view);
        trackPosition(entity, view);
        entities.add(view);
        
    }
	
	private void trackPosition(Entity entity, Node node) {
        GridPane.setColumnIndex(node, entity.getX());
        GridPane.setRowIndex(node, entity.getY());
        entity.x().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
            	
                GridPane.setColumnIndex(node, newValue.intValue());
            }
        });
        entity.y().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
                GridPane.setRowIndex(node, newValue.intValue());
            }
        });
        
    }
	
	
	
	@FXML
	public void initialize() {
		widthid.setItems(list);
		heightid.setItems(list);
		playerx.setItems(list);
		playery.setItems(list);
		goalid.setItems(goallist);
	}
	
	@FXML
	public void handleWidth(ActionEvent event) {
		width = widthid.getValue();
	}
	
	@FXML
	public void handleHeight(ActionEvent event) {
		height = heightid.getValue();
	}
	
	@FXML
	public void handlePx(ActionEvent event) {
		px = playerx.getValue();
	}
	
	@FXML
	public void handlePy(ActionEvent event) {
		py = playery.getValue();
	}
	
	public CustomerController(Stage stage) {
		this.stage = stage;
		this.entities = new ArrayList<>();
		playerImage = new Image("/human_new.png");
	    wallImage = new Image("/brick_brown_0.png");
	    enemyImage = new Image("/gnome.png");
	    exitImage = new Image("/exit.png");
	    swordImage = new Image("/greatsword_1_new.png");
	    treasureImage = new Image("/gold_pile.png");
	    potionImage = new Image("/brilliant_blue_new.png");
	    bombImage = new Image("/bomb_unlit.png");
	    boulderImage = new Image("/boulder.png");
	    switchImage = new Image("/pressure_plate.png");
	    doorImage = new Image("/closed_door.png");
	    door1Image = new Image("/door1.png");
	    door2Image = new Image("/door2.png");
	    door3Image = new Image("/door3.png");
	    keyImage = new Image("/key.png");
	    key1Image = new Image("/key1.png");
	    key2Image = new Image("/key2.png");
	    key3Image = new Image("/key3.png");
	    dogImage = new Image("/hound.png");
	    emptyImage = new Image("/dirt_0_new.png");
	}

}
